-- Create teacher_applications table
CREATE TABLE IF NOT EXISTS teacher_applications (
    id VARCHAR(36) NOT NULL PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    native_language VARCHAR(100) NOT NULL,
    teaching_languages JSON NOT NULL,
    experience TEXT NOT NULL,
    education TEXT,
    certifications JSON,
    availability JSON,
    hourly_rate DECIMAL(8,2),
    bio TEXT NOT NULL,
    profile_image VARCHAR(500) NOT NULL,
    video_introduction VARCHAR(500) NOT NULL,
    status ENUM('pending', 'approved', 'rejected', 'needs_revision') NOT NULL DEFAULT 'pending',
    submitted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reviewed_at TIMESTAMP NULL,
    reviewed_by BIGINT UNSIGNED NULL,
    rejection_reason TEXT NULL,
    edit_suggestions TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL,
    
    INDEX idx_user_id (user_id),
    INDEX idx_status (status),
    INDEX idx_submitted_at (submitted_at)
);
