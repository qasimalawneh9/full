import { Request, Response } from "express";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import crypto from "crypto";

// Mock user data for development
const mockUsers = [
  {
    id: 1,
    email: "admin@talkcon.com",
    password: "$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj7.k3yP.B3e", // password: 123456
    role: "admin",
    status: "active",
    emailVerified: true,
    twoFactorEnabled: false,
    name: "Admin User",
  },
  {
    id: 2,
    email: "teacher@talkcon.com",
    password: "$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj7.k3yP.B3e", // password: 123456
    role: "teacher",
    status: "active",
    emailVerified: true,
    twoFactorEnabled: false,
    name: "Teacher User",
  },
  {
    id: 3,
    email: "student@talkcon.com",
    password: "$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj7.k3yP.B3e", // password: 123456
    role: "student",
    status: "active",
    emailVerified: true,
    twoFactorEnabled: false,
    name: "Student User",
  },
];

// Mock storage for password reset tokens, email verification, teacher applications, and OAuth
const passwordResetTokens = new Map();
const emailVerificationTokens = new Map();
const twoFactorSecrets = new Map();
export const teacherApplications = new Map();
const oauthStates = new Map();

export const login = async (req: Request, res: Response) => {
  try {
    const { email, password, twoFactorCode } = req.body;

    if (!email || !password) {
      return res
        .status(400)
        .json({ message: "Email and password are required" });
    }

    // Find user in mock data
    const user = mockUsers.find((u) => u.email === email);

    if (!user) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    // Verify password
    const isPasswordValid = await bcrypt.compare(password, user.password);

    if (!isPasswordValid) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    // Check if account is active
    if (user.status !== "active") {
      return res.status(403).json({ message: "Account is not active" });
    }

    // Check 2FA if enabled
    if (user.twoFactorEnabled) {
      if (!twoFactorCode) {
        return res.status(200).json({
          message: "Two-factor authentication required",
          requires2FA: true,
        });
      }

      // Mock 2FA verification - in real app, verify TOTP
      if (twoFactorCode !== "123456") {
        return res.status(400).json({ message: "Invalid 2FA code" });
      }
    }

    // Generate JWT token
    const token = jwt.sign(
      {
        userId: user.id,
        email: user.email,
        role: user.role,
      },
      process.env.JWT_SECRET || "default_secret",
      { expiresIn: "24h" },
    );

    // Return user data and token
    const { password: _, ...userWithoutPassword } = user;

    res.status(200).json({
      message: "Login successful",
      access_token: token,
      user: userWithoutPassword,
    });
  } catch (error) {
    return res.status(500).json({ message: "Internal server error" });
  }
};

export const register = async (req: Request, res: Response) => {
  try {
    const { email, password, name, role } = req.body;

    if (!email || !password || !name) {
      return res
        .status(400)
        .json({ message: "Email, password, and name are required" });
    }

    // Check if user already exists
    const existingUser = mockUsers.find((u) => u.email === email);
    if (existingUser) {
      return res.status(409).json({ message: "User already exists" });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12);

    // Create new user - all users register as students by default
    const newUser = {
      id: mockUsers.length + 1,
      email,
      password: hashedPassword,
      name,
      role: role || "student", // Default to student role
      status: "active",
      emailVerified: false,
      twoFactorEnabled: false,
    };

    // Add to mock database
    mockUsers.push(newUser);

    // Generate email verification token
    const verificationToken = crypto.randomBytes(32).toString("hex");
    emailVerificationTokens.set(verificationToken, {
      userId: newUser.id,
      email: newUser.email,
      expires: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
    });

    // Generate JWT token for immediate login
    const token = jwt.sign(
      {
        userId: newUser.id,
        email: newUser.email,
        role: newUser.role,
      },
      process.env.JWT_SECRET || "default_secret",
      { expiresIn: "24h" },
    );

    // Return user data and token
    const { password: _, ...userWithoutPassword } = newUser;

    res.status(201).json({
      message: "User registered successfully",
      access_token: token,
      user: userWithoutPassword,
      verificationToken,
    });
  } catch (error) {
    return res.status(500).json({ message: "Internal server error" });
  }
};

export const logout = async (req: Request, res: Response) => {
  try {
    // In a real app, you would invalidate the token here
    // For JWT, this could mean adding to a blacklist or using short-lived tokens

    res.status(200).json({ message: "Logout successful" });
  } catch (error) {
    return res.status(500).json({ message: "Internal server error" });
  }
};

export const refreshToken = async (req: Request, res: Response) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return res.status(400).json({ message: "Refresh token is required" });
    }

    // Verify refresh token (simplified for demo)
    const decoded = jwt.verify(
      refreshToken,
      process.env.JWT_SECRET || "default_secret",
    ) as any;

    // Find user
    const user = mockUsers.find((u) => u.id === decoded.userId);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Generate new access token
    const newToken = jwt.sign(
      {
        userId: user.id,
        email: user.email,
        role: user.role,
      },
      process.env.JWT_SECRET || "default_secret",
      { expiresIn: "24h" },
    );

    res.status(200).json({
      access_token: newToken,
    });
  } catch (error) {
    return res.status(401).json({ message: "Invalid refresh token" });
  }
};

export const forgotPassword = async (req: Request, res: Response) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ message: "Email is required" });
    }

    const user = mockUsers.find((u) => u.email === email);

    if (!user) {
      // Don't reveal whether user exists
      return res
        .status(200)
        .json({ message: "If account exists, password reset email sent" });
    }

    // Generate reset token
    const resetToken = crypto.randomBytes(32).toString("hex");
    passwordResetTokens.set(resetToken, {
      userId: user.id,
      email: user.email,
      expires: Date.now() + 60 * 60 * 1000, // 1 hour
    });

    // In real app, send email here
    console.log(`Password reset token for ${email}: ${resetToken}`);

    res
      .status(200)
      .json({ message: "If account exists, password reset email sent" });
  } catch (error) {
    return res.status(500).json({ message: "Internal server error" });
  }
};

export const resetPassword = async (req: Request, res: Response) => {
  try {
    const { token, newPassword } = req.body;

    if (!token || !newPassword) {
      return res
        .status(400)
        .json({ message: "Token and new password are required" });
    }

    const resetData = passwordResetTokens.get(token);

    if (!resetData || resetData.expires < Date.now()) {
      return res.status(400).json({ message: "Invalid or expired token" });
    }

    // Find user and update password
    const user = mockUsers.find((u) => u.id === resetData.userId);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Hash new password
    user.password = await bcrypt.hash(newPassword, 12);

    // Remove used token
    passwordResetTokens.delete(token);

    res.status(200).json({ message: "Password reset successful" });
  } catch (error) {
    return res.status(500).json({ message: "Internal server error" });
  }
};

export const verifyEmail = async (req: Request, res: Response) => {
  try {
    const { token } = req.body;

    if (!token) {
      return res
        .status(400)
        .json({ message: "Verification token is required" });
    }

    const verificationData = emailVerificationTokens.get(token);

    if (!verificationData || verificationData.expires < Date.now()) {
      return res.status(400).json({ message: "Invalid or expired token" });
    }

    // Find user and mark as verified
    const user = mockUsers.find((u) => u.id === verificationData.userId);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    user.emailVerified = true;

    // Remove used token
    emailVerificationTokens.delete(token);

    res.status(200).json({ message: "Email verified successfully" });
  } catch (error) {
    return res.status(500).json({ message: "Internal server error" });
  }
};

export const resendVerification = async (req: Request, res: Response) => {
  try {
    const user = req.user; // From auth middleware

    if (!user) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    // Generate new verification token
    const verificationToken = crypto.randomBytes(32).toString("hex");
    emailVerificationTokens.set(verificationToken, {
      userId: user.id,
      email: user.email,
      expires: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
    });

    // In real app, send email here
    console.log(`Verification token for ${user.email}: ${verificationToken}`);

    res.status(200).json({ message: "Verification email sent" });
  } catch (error) {
    return res.status(500).json({ message: "Internal server error" });
  }
};

export const enable2FA = async (req: Request, res: Response) => {
  try {
    const user = req.user; // From auth middleware

    if (!user) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    // Generate secret (in real app, use speakeasy)
    const secret = crypto.randomBytes(20).toString("hex");
    twoFactorSecrets.set(user.id, secret);

    res.status(200).json({
      message: "2FA setup initiated",
      secret,
      qrCode: `otpauth://totp/Talkcon:${user.email}?secret=${secret}&issuer=Talkcon`,
    });
  } catch (error) {
    return res.status(500).json({ message: "Internal server error" });
  }
};

export const disable2FA = async (req: Request, res: Response) => {
  try {
    const user = req.user; // From auth middleware

    if (!user) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    // Find and update user
    const mockUser = mockUsers.find((u) => u.id === user.id);
    if (mockUser) {
      mockUser.twoFactorEnabled = false;
      twoFactorSecrets.delete(user.id);
    }

    res.status(200).json({ message: "Two-factor authentication disabled" });
  } catch (error) {
    return res.status(500).json({ message: "Internal server error" });
  }
};

export const verify2FA = async (req: Request, res: Response) => {
  try {
    const { email, code } = req.body;

    if (!email || !code) {
      return res.status(400).json({ message: "Email and code are required" });
    }

    const user = mockUsers.find((u) => u.email === email);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Mock verification - in real app, verify TOTP code
    if (code === "123456") {
      user.twoFactorEnabled = true;
      return res
        .status(200)
        .json({ message: "Two-factor authentication enabled successfully" });
    } else {
      return res.status(400).json({ message: "Invalid verification code" });
    }
  } catch (error) {
    return res.status(500).json({ message: "Internal server error" });
  }
};

// OAuth endpoints

// Start OAuth flow
export const startOAuth = async (req: Request, res: Response) => {
  try {
    const { provider } = req.params;

    if (!["google", "facebook", "apple"].includes(provider)) {
      return res.status(400).json({ message: "Unsupported OAuth provider" });
    }

    // Generate state parameter for security
    const state = crypto.randomBytes(32).toString("hex");
    oauthStates.set(state, {
      provider,
      expires: Date.now() + 10 * 60 * 1000, // 10 minutes
    });

    // Mock OAuth URLs - in production, use real OAuth provider URLs
    const mockOAuthUrls = {
      google: `https://accounts.google.com/oauth/authorize?client_id=mock&redirect_uri=${encodeURIComponent(process.env.FRONTEND_URL || "http://localhost:3000")}/auth/callback/google&response_type=code&scope=email profile&state=${state}`,
      facebook: `https://www.facebook.com/v18.0/dialog/oauth?client_id=mock&redirect_uri=${encodeURIComponent(process.env.FRONTEND_URL || "http://localhost:3000")}/auth/callback/facebook&scope=email&state=${state}`,
      apple: `https://appleid.apple.com/auth/authorize?client_id=mock&redirect_uri=${encodeURIComponent(process.env.FRONTEND_URL || "http://localhost:3000")}/auth/callback/apple&response_type=code&scope=email name&state=${state}`,
    };

    res.status(200).json({
      url: mockOAuthUrls[provider as keyof typeof mockOAuthUrls],
      state,
    });
  } catch (error) {
    return res.status(500).json({ message: "Internal server error" });
  }
};

// Handle OAuth callback
export const handleOAuthCallback = async (req: Request, res: Response) => {
  try {
    const { provider } = req.params;
    const { code, state } = req.query;

    if (!code || !state) {
      return res
        .status(400)
        .json({ message: "Missing authorization code or state" });
    }

    // Verify state parameter
    const stateData = oauthStates.get(state);
    if (
      !stateData ||
      stateData.expires < Date.now() ||
      stateData.provider !== provider
    ) {
      return res
        .status(400)
        .json({ message: "Invalid or expired state parameter" });
    }

    // Clean up state
    oauthStates.delete(state);

    // Mock OAuth token exchange - in production, exchange code for token with OAuth provider
    const mockUserData = {
      google: {
        id: `google_${Date.now()}`,
        email: "user@gmail.com",
        name: "Google User",
        picture: "https://via.placeholder.com/150",
      },
      facebook: {
        id: `facebook_${Date.now()}`,
        email: "user@facebook.com",
        name: "Facebook User",
        picture: "https://via.placeholder.com/150",
      },
      apple: {
        id: `apple_${Date.now()}`,
        email: "user@icloud.com",
        name: "Apple User",
        picture: "https://via.placeholder.com/150",
      },
    };

    const oauthUserData = mockUserData[provider as keyof typeof mockUserData];

    if (!oauthUserData) {
      return res.status(400).json({ message: "Unsupported OAuth provider" });
    }

    // Check if user already exists
    let user = mockUsers.find((u) => u.email === oauthUserData.email);

    if (!user) {
      // Create new user
      user = {
        id: mockUsers.length + 1,
        email: oauthUserData.email,
        password: "", // OAuth users don't have passwords
        name: oauthUserData.name,
        role: "student", // Default role
        status: "active",
        emailVerified: true, // OAuth users are pre-verified
        twoFactorEnabled: false,
        provider,
        providerId: oauthUserData.id,
        avatar: oauthUserData.picture,
      };

      mockUsers.push(user);
    }

    // Generate JWT token
    const token = jwt.sign(
      {
        userId: user.id,
        email: user.email,
        role: user.role,
      },
      process.env.JWT_SECRET || "default_secret",
      { expiresIn: "24h" },
    );

    // Return user data and token
    const { password: _, ...userWithoutPassword } = user;

    res.status(200).json({
      message: "OAuth login successful",
      access_token: token,
      user: userWithoutPassword,
    });
  } catch (error) {
    console.error("OAuth callback error:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

// New teacher application endpoint
export const applyTeacher = async (req: Request, res: Response) => {
  try {
    const user = req.user; // From auth middleware

    if (!user) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const {
      firstName,
      lastName,
      nativeLanguage,
      teachingLanguages,
      experience,
      education,
      certifications,
      availability,
      hourlyRate,
      bio,
      videoIntroduction,
      profileImage,
    } = req.body;

    // Validate required fields
    if (
      !firstName ||
      !lastName ||
      !nativeLanguage ||
      !teachingLanguages ||
      !experience ||
      !bio ||
      !profileImage ||
      !videoIntroduction
    ) {
      return res.status(400).json({
        message:
          "Missing required fields: firstName, lastName, nativeLanguage, teachingLanguages, experience, bio, profileImage, videoIntroduction",
      });
    }

    // Check if user already has a pending or approved teacher application
    const existingApplication = Array.from(teacherApplications.values()).find(
      (app) => app.userId === user.id,
    );

    if (existingApplication) {
      return res.status(409).json({
        message: "Teacher application already exists",
        status: existingApplication.status,
      });
    }

    // Create teacher application
    const applicationId = crypto.randomBytes(16).toString("hex");
    const application = {
      id: applicationId,
      userId: user.id,
      email: user.email,
      firstName,
      lastName,
      nativeLanguage,
      teachingLanguages: Array.isArray(teachingLanguages)
        ? teachingLanguages
        : [teachingLanguages],
      experience,
      education: education || "",
      certifications: certifications || [],
      availability: availability || {},
      hourlyRate: hourlyRate || 0,
      bio: bio || "",
      videoIntroduction: videoIntroduction || "",
      profileImage: profileImage || "",
      status: "pending", // pending, approved, rejected, needs_revision
      submittedAt: new Date().toISOString(),
      reviewedAt: null,
      reviewedBy: null,
      rejectionReason: null,
    };

    // Store application
    teacherApplications.set(applicationId, application);

    res.status(201).json({
      message: "Teacher application submitted successfully",
      applicationId,
      status: "pending",
    });
  } catch (error) {
    console.error("Teacher application error:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

// Get teacher application status
export const getTeacherApplicationStatus = async (
  req: Request,
  res: Response,
) => {
  try {
    const user = req.user; // From auth middleware

    if (!user) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    // Find application for this user
    const application = Array.from(teacherApplications.values()).find(
      (app) => app.userId === user.id,
    );

    if (!application) {
      return res.status(404).json({ message: "No teacher application found" });
    }

    // Return application status (without sensitive admin data)
    const publicApplication = {
      id: application.id,
      status: application.status,
      submittedAt: application.submittedAt,
      reviewedAt: application.reviewedAt,
      rejectionReason: application.rejectionReason,
    };

    res.status(200).json(publicApplication);
  } catch (error) {
    return res.status(500).json({ message: "Internal server error" });
  }
};

// Check if user is also a teacher (for dashboard switching)
export const checkTeacherStatus = async (req: Request, res: Response) => {
  try {
    const user = req.user; // From auth middleware

    if (!user) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    // Check if user has an approved teacher application
    const application = Array.from(teacherApplications.values()).find(
      (app) => app.userId === user.id && app.status === "approved",
    );

    const isTeacher = !!application;

    res.status(200).json({
      isTeacher,
      applicationStatus: application ? application.status : null,
    });
  } catch (error) {
    return res.status(500).json({ message: "Internal server error" });
  }
};
