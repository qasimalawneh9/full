import { DataTypes, Model, Optional } from "sequelize";
import sequelize from "../config/database";
import User from "./user.model";

interface TeacherApplicationAttributes {
  id: string;
  userId: number;
  firstName: string;
  lastName: string;
  email: string;
  nativeLanguage: string;
  teachingLanguages: string[];
  experience: string;
  education?: string;
  certifications?: string[];
  availability?: object;
  hourlyRate?: number;
  bio: string;
  profileImage: string;
  videoIntroduction: string;
  status: "pending" | "approved" | "rejected" | "needs_revision";
  submittedAt: Date;
  reviewedAt?: Date | null;
  reviewedBy?: number | null;
  rejectionReason?: string | null;
  editSuggestions?: string | null;
  createdAt?: Date;
  updatedAt?: Date;
}

type TeacherApplicationCreationAttributes = Optional<
  TeacherApplicationAttributes,
  | "id"
  | "education"
  | "certifications"
  | "availability"
  | "hourlyRate"
  | "reviewedAt"
  | "reviewedBy"
  | "rejectionReason"
  | "editSuggestions"
  | "createdAt"
  | "updatedAt"
>;

class TeacherApplication
  extends Model<
    TeacherApplicationAttributes,
    TeacherApplicationCreationAttributes
  >
  implements TeacherApplicationAttributes
{
  public id!: string;
  public userId!: number;
  public firstName!: string;
  public lastName!: string;
  public email!: string;
  public nativeLanguage!: string;
  public teachingLanguages!: string[];
  public experience!: string;
  public education!: string;
  public certifications!: string[];
  public availability!: object;
  public hourlyRate!: number;
  public bio!: string;
  public profileImage!: string;
  public videoIntroduction!: string;
  public status!: "pending" | "approved" | "rejected" | "needs_revision";
  public submittedAt!: Date;
  public reviewedAt!: Date | null;
  public reviewedBy!: number | null;
  public rejectionReason!: string | null;
  public editSuggestions!: string | null;

  // timestamps
  public readonly createdAt!: Date;
  public readonly updatedAt!: Date;
}

TeacherApplication.init(
  {
    id: {
      type: DataTypes.STRING,
      primaryKey: true,
      allowNull: false,
    },
    userId: {
      type: DataTypes.BIGINT.UNSIGNED,
      allowNull: false,
      field: "user_id",
      references: {
        model: User,
        key: "id",
      },
    },
    firstName: {
      type: DataTypes.STRING(100),
      allowNull: false,
      field: "first_name",
    },
    lastName: {
      type: DataTypes.STRING(100),
      allowNull: false,
      field: "last_name",
    },
    email: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    nativeLanguage: {
      type: DataTypes.STRING(100),
      allowNull: false,
      field: "native_language",
    },
    teachingLanguages: {
      type: DataTypes.JSON,
      allowNull: false,
      field: "teaching_languages",
    },
    experience: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    education: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    certifications: {
      type: DataTypes.JSON,
      allowNull: true,
    },
    availability: {
      type: DataTypes.JSON,
      allowNull: true,
    },
    hourlyRate: {
      type: DataTypes.DECIMAL(8, 2),
      allowNull: true,
      field: "hourly_rate",
    },
    bio: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    profileImage: {
      type: DataTypes.STRING(500),
      allowNull: false,
      field: "profile_image",
    },
    videoIntroduction: {
      type: DataTypes.STRING(500),
      allowNull: false,
      field: "video_introduction",
    },
    status: {
      type: DataTypes.ENUM("pending", "approved", "rejected", "needs_revision"),
      allowNull: false,
      defaultValue: "pending",
    },
    submittedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
      field: "submitted_at",
    },
    reviewedAt: {
      type: DataTypes.DATE,
      allowNull: true,
      field: "reviewed_at",
    },
    reviewedBy: {
      type: DataTypes.BIGINT.UNSIGNED,
      allowNull: true,
      field: "reviewed_by",
      references: {
        model: User,
        key: "id",
      },
    },
    rejectionReason: {
      type: DataTypes.TEXT,
      allowNull: true,
      field: "rejection_reason",
    },
    editSuggestions: {
      type: DataTypes.TEXT,
      allowNull: true,
      field: "edit_suggestions",
    },
  },
  {
    sequelize,
    tableName: "teacher_applications",
    underscored: true,
    timestamps: true,
  },
);

// Define associations
TeacherApplication.belongsTo(User, {
  foreignKey: "userId",
  as: "user",
});

TeacherApplication.belongsTo(User, {
  foreignKey: "reviewedBy",
  as: "reviewer",
});

export default TeacherApplication;
