# Footer Positioning Guide

## Problem

Some pages may have short content that doesn't fill the viewport, causing the footer to appear in the middle of the screen instead of at the bottom.

## Solution

Use the CSS utilities added to `global.css` to ensure proper footer positioning.

## Method 1: Using CSS Classes

### For pages with footer:

```tsx
return (
  <div className="min-h-screen-flex bg-background">
    <div className="flex-grow">
      <Navbar />
      {/* Your page content */}
      <div className="container mx-auto px-4 py-8">
        {/* Content goes here */}
      </div>
    </div>
    <Footer />
  </div>
);
```

### For pages without footer (dashboards):

```tsx
return (
  <div className="min-h-screen bg-background">
    <Navbar />
    {/* Dashboard content */}
  </div>
);
```

## Method 2: Using the PageWrapper Component

```tsx
import { PageWrapper } from "@/components/layout/PageWrapper";

return (
  <PageWrapper className="bg-background">
    <Navbar />
    <div className="container mx-auto px-4 py-8">{/* Your page content */}</div>
  </PageWrapper>
);
```

## Current Status

The following utility classes are available in `global.css`:

- `.min-h-screen-flex` - Sets min-height: 100vh and flex column layout
- `.flex-grow` - Makes element grow to fill available space
- `.page-with-footer` - Complete layout wrapper for pages with footers
- `.main-content` - Content area that grows to push footer down
- `.footer-bottom` - Ensures footer stays at bottom

## Implementation

Most pages are already correctly structured with `min-h-screen` containers. The footer naturally appears at the bottom when there's enough content. For pages with minimal content, apply the flex utilities as shown above.

### Pages that should have footers:

- Marketing/landing pages (Index, BecomeTeacher, etc.)
- Information pages (Help, Contact, Legal, etc.)
- Teacher search and profiles
- Public content pages

### Pages that should NOT have footers:

- Authentication pages (Login, Signup)
- Dashboard pages (Student, Teacher, Admin dashboards)
- Application forms and workflows
