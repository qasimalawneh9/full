/**
 * Admin API Service
 *
 * Handles admin operations with backend API endpoints
 */

import { BaseApiService } from "../base.service";

export interface TeacherApplicationData {
  id: string;
  teacherId: string;
  teacherName: string;
  teacherEmail: string;
  status: "pending" | "approved" | "rejected" | "needs_revision";
  applicationData: {
    firstName: string;
    lastName: string;
    nativeLanguage: string;
    teachingLanguages: string[];
    experience: string;
    education?: string;
    certifications?: string[];
    hourlyRate?: number;
    bio: string;
    profileImage: string;
    videoIntroduction: string;
  };
  submittedAt: string;
  reviewedAt?: string;
  rejectionReason?: string;
  editSuggestions?: string;
}

export class AdminApiService extends BaseApiService {
  /**
   * Get all teacher applications
   * GET /api/admin/teacher-applications
   */
  async getTeacherApplications(): Promise<TeacherApplicationData[]> {
    const response = await this.get<{ data: TeacherApplicationData[] }>(
      "/admin/teacher-applications",
    );
    return response.data || [];
  }

  /**
   * Approve teacher application
   * POST /api/admin/teacher-applications/:id/approve
   */
  async approveTeacherApplication(applicationId: string): Promise<boolean> {
    try {
      await this.post(
        `/admin/teacher-applications/${applicationId}/approve`,
        {},
      );
      return true;
    } catch (error) {
      console.error("Failed to approve teacher application:", error);
      return false;
    }
  }

  /**
   * Reject teacher application
   * POST /api/admin/teacher-applications/:id/reject
   */
  async rejectTeacherApplication(
    applicationId: string,
    reason: string,
  ): Promise<boolean> {
    try {
      await this.post(`/admin/teacher-applications/${applicationId}/reject`, {
        reason,
      });
      return true;
    } catch (error) {
      console.error("Failed to reject teacher application:", error);
      return false;
    }
  }

  /**
   * Request edits to teacher application
   * POST /api/admin/teacher-applications/:id/request-edits
   */
  async requestApplicationEdits(
    applicationId: string,
    suggestions: string,
  ): Promise<boolean> {
    try {
      await this.post(
        `/admin/teacher-applications/${applicationId}/request-edits`,
        { suggestions },
      );
      return true;
    } catch (error) {
      console.error("Failed to request application edits:", error);
      return false;
    }
  }

  /**
   * Get dashboard stats
   * GET /api/admin/dashboard
   */
  async getDashboardStats(): Promise<any> {
    const response = await this.get("/admin/dashboard");
    return response.data || {};
  }

  /**
   * Get all users
   * GET /api/admin/users
   */
  async getUsers(): Promise<any[]> {
    const response = await this.get<{ data: any[] }>("/admin/users");
    return response.data || [];
  }

  /**
   * Get all teachers
   * GET /api/admin/teachers
   */
  async getTeachers(): Promise<any[]> {
    const response = await this.get<{ data: any[] }>("/admin/teachers");
    return response.data || [];
  }

  /**
   * Approve teacher
   * POST /api/admin/teachers/:id/approve
   */
  async approveTeacher(teacherId: string): Promise<boolean> {
    try {
      await this.post(`/admin/teachers/${teacherId}/approve`, {});
      return true;
    } catch (error) {
      console.error("Failed to approve teacher:", error);
      return false;
    }
  }

  /**
   * Reject teacher
   * POST /api/admin/teachers/:id/reject
   */
  async rejectTeacher(teacherId: string, reason: string): Promise<boolean> {
    try {
      await this.post(`/admin/teachers/${teacherId}/reject`, { reason });
      return true;
    } catch (error) {
      console.error("Failed to reject teacher:", error);
      return false;
    }
  }
}

// Export singleton instance
export const adminApiService = new AdminApiService();
