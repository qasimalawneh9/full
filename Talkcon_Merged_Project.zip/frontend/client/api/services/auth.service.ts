/**
 * Authentication Service
 *
 * Handles all authentication-related API calls
 * Maps to Node.js Express AuthController
 */

import { BaseApiService } from "../base.service";
import { AUTH_ENDPOINTS, USER_ENDPOINTS } from "../endpoints";
import { AuthResponse, User } from "../config";

// Request types - matching our backend
export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterData {
  email: string;
  password: string;
  name: string;
  role?: "student" | "teacher" | "admin";
}

export interface TeacherApplicationData {
  firstName: string;
  lastName: string;
  nativeLanguage: string;
  teachingLanguages: string[];
  experience: string;
  education?: string;
  certifications?: string[];
  availability?: any;
  hourlyRate?: number;
  bio?: string;
  videoIntroduction?: string;
}

export interface TeacherApplicationStatus {
  id: string;
  status: "pending" | "approved" | "rejected";
  submittedAt: string;
  reviewedAt?: string;
  rejectionReason?: string;
}

export interface OAuthStartResponse {
  url: string;
  state: string;
}

/**
 * AuthService class
 *
 * Usage Example:
 * ```typescript
 * const authService = new AuthService();
 *
 * // Login
 * const response = await authService.login({
 *   email: 'admin@talkcon.com',
 *   password: '123456'
 * });
 *
 * // Register
 * const user = await authService.register({
 *   email: 'john@example.com',
 *   password: 'password',
 *   name: 'John Doe',
 *   role: 'student'
 * });
 *
 * // OAuth Login
 * const oauthUrl = await authService.startOAuth('google');
 * // User is redirected to Google OAuth, then back to callback
 * const result = await authService.handleOAuthCallback('google', code, state);
 * ```
 */
export class AuthService extends BaseApiService {
  /**
   * Login user
   * POST /api/auth/login → AuthController@login
   */
  async login(credentials: LoginCredentials): Promise<AuthResponse> {
    const response = await this.post<AuthResponse>(
      AUTH_ENDPOINTS.LOGIN,
      credentials,
      false, // No auth required for login
    );

    // Our backend returns the response directly, not wrapped in data
    return response.data || response;
  }

  /**
   * Register new user
   * POST /api/auth/register → AuthController@register
   */
  async register(
    userData: RegisterData,
  ): Promise<{ message: string; user: Partial<User>; access_token: string }> {
    const response = await this.post<{
      message: string;
      user: Partial<User>;
      access_token: string;
    }>(
      AUTH_ENDPOINTS.REGISTER,
      userData,
      false, // No auth required for registration
    );

    return response.data || response;
  }

  /**
   * Start OAuth flow
   * GET /api/auth/oauth/:provider → AuthController@startOAuth
   */
  async startOAuth(
    provider: "google" | "facebook" | "apple",
  ): Promise<OAuthStartResponse> {
    const response = await this.get<OAuthStartResponse>(
      `${AUTH_ENDPOINTS.OAUTH_START}/${provider}`,
      false, // No auth required
    );

    return response.data || response;
  }

  /**
   * Handle OAuth callback
   * POST /api/auth/oauth/:provider/callback → AuthController@handleOAuthCallback
   */
  async handleOAuthCallback(
    provider: "google" | "facebook" | "apple",
    code: string,
    state: string,
  ): Promise<{ message: string; access_token: string; user: Partial<User> }> {
    const response = await this.post<{
      message: string;
      access_token: string;
      user: Partial<User>;
    }>(
      `${AUTH_ENDPOINTS.OAUTH_CALLBACK}/${provider}/callback`,
      { code, state },
      false, // No auth required
    );

    return response.data || response;
  }

  /**
   * Logout user
   * POST /api/auth/logout → AuthController@logout
   */
  async logout(): Promise<{ message: string }> {
    const response = await this.post<{ message: string }>(
      AUTH_ENDPOINTS.LOGOUT,
    );
    return response.data || response;
  }

  /**
   * Get authenticated user profile
   * GET /api/users/me → UserController@getCurrentUser
   */
  async getProfile(): Promise<{ user: User }> {
    const response = await this.get<{ user: User }>(USER_ENDPOINTS.PROFILE);
    return response.data || response;
  }

  /**
   * Apply to become a teacher
   * POST /api/auth/apply-teacher → AuthController@applyTeacher
   */
  async applyTeacher(
    applicationData: TeacherApplicationData,
  ): Promise<{ message: string; applicationId: string; status: string }> {
    const response = await this.post<{
      message: string;
      applicationId: string;
      status: string;
    }>(
      "/auth/apply-teacher",
      applicationData,
      true, // Auth required
    );

    return response.data || response;
  }

  /**
   * Get teacher application status
   * GET /api/auth/teacher-application-status → AuthController@getTeacherApplicationStatus
   */
  async getTeacherApplicationStatus(): Promise<TeacherApplicationStatus> {
    const response = await this.get<TeacherApplicationStatus>(
      "/auth/teacher-application-status",
    );
    return response.data || response;
  }

  /**
   * Check if user is also a teacher (for dashboard switching)
   * GET /api/auth/check-teacher-status → AuthController@checkTeacherStatus
   */
  async checkTeacherStatus(): Promise<{
    isTeacher: boolean;
    applicationStatus: string | null;
  }> {
    const response = await this.get<{
      isTeacher: boolean;
      applicationStatus: string | null;
    }>("/auth/check-teacher-status");
    return response.data || response;
  }

  /**
   * Send forgot password email
   * POST /api/auth/forgot-password → AuthController@forgotPassword
   */
  async forgotPassword(email: string): Promise<{ message: string }> {
    const response = await this.post<{ message: string }>(
      AUTH_ENDPOINTS.FORGOT_PASSWORD,
      { email },
      false, // No auth required
    );
    return response.data || response;
  }

  /**
   * Reset password with token
   * POST /api/auth/reset-password → AuthController@resetPassword
   */
  async resetPassword(
    token: string,
    newPassword: string,
  ): Promise<{ message: string }> {
    const response = await this.post<{ message: string }>(
      AUTH_ENDPOINTS.RESET_PASSWORD,
      { token, newPassword },
      false, // No auth required
    );
    return response.data || response;
  }
}

// Export singleton instance
export const authService = new AuthService();
