import { API_CONFIG } from "../config";

export interface LessonRecord {
  id: string;
  timestamp: string;
  action: string;
  status: "pending" | "completed" | "failed" | "in_progress";
  details: string;
  actor: "student" | "teacher" | "system";
  metadata?: {
    amount?: number;
    duration?: number;
    reason?: string;
    rating?: number;
  };
}

export interface Teacher {
  id: string;
  name: string;
  avatar: string;
  rating: number;
  totalReviews: number;
  language: string;
  hourlyRate: number;
}

export interface LessonDetails {
  id: string;
  title: string;
  description: string;
  teacher: Teacher;
  studentId: string;
  language: string;
  date: string;
  time: string;
  duration: number;
  status: "scheduled" | "in_progress" | "completed" | "cancelled" | "no_show";
  type: "trial" | "regular" | "group";
  price: number;
  currency: string;
  meetingUrl?: string;
  recordingUrl?: string;
  materials: string[];
  homework?: {
    assigned: string;
    completed: boolean;
    dueDate?: string;
  };
  feedback?: {
    teacher: string;
    student: string;
    rating: number;
  };
  notes: string;
  bookingReference: string;
  paymentStatus: "pending" | "completed" | "failed" | "refunded";
  cancellationPolicy: string;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
}

class LessonDetailsService {
  private baseUrl = `${API_CONFIG.BASE_URL}/lessons`;

  async getLessonDetails(
    lessonId: string,
  ): Promise<ApiResponse<LessonDetails>> {
    try {
      const token = localStorage.getItem("auth_token");
      const response = await fetch(`${this.baseUrl}/${lessonId}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: token ? `Bearer ${token}` : "",
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      return result;
    } catch (error) {
      console.error("Error fetching lesson details:", error);

      // Fallback to demo data if API fails
      return {
        success: true,
        data: this.getDemoLessonDetails(lessonId),
      };
    }
  }

  async getLessonHistory(
    lessonId: string,
  ): Promise<ApiResponse<{ lessonId: string; records: LessonRecord[] }>> {
    try {
      const token = localStorage.getItem("auth_token");
      const response = await fetch(`${this.baseUrl}/${lessonId}/history`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: token ? `Bearer ${token}` : "",
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      return result;
    } catch (error) {
      console.error("Error fetching lesson history:", error);

      // Fallback to demo data if API fails
      return {
        success: true,
        data: {
          lessonId,
          records: this.getDemoLessonHistory(),
        },
      };
    }
  }

  private getDemoLessonDetails(lessonId: string): LessonDetails {
    return {
      id: lessonId,
      title: "Conversational Spanish - Travel Vocabulary",
      description:
        "Focus on practical Spanish phrases and vocabulary for travel situations. We'll cover airport, hotel, restaurant, and shopping scenarios.",
      teacher: {
        id: "TCH_001",
        name: "María García",
        avatar: "/placeholder.svg",
        rating: 4.8,
        totalReviews: 127,
        language: "Spanish",
        hourlyRate: 25,
      },
      studentId: "STU_001",
      language: "Spanish",
      date: "2024-01-25",
      time: "14:00",
      duration: 60,
      status: "scheduled",
      type: "regular",
      price: 25,
      currency: "USD",
      meetingUrl: "https://meet.google.com/abc-defg-hij",
      materials: [
        "Travel Vocabulary Worksheet.pdf",
        "Common Phrases Guide.pdf",
        "Audio Pronunciation Examples.mp3",
      ],
      homework: {
        assigned:
          "Practice 10 travel phrases and record yourself speaking them",
        completed: false,
        dueDate: "2024-01-27",
      },
      notes:
        "Student has intermediate level. Focus on pronunciation and confidence building.",
      bookingReference: `BKG_20240120_${lessonId}`,
      paymentStatus: "completed",
      cancellationPolicy: "Free cancellation up to 24 hours before the lesson",
    };
  }

  private getDemoLessonHistory(): LessonRecord[] {
    return [
      {
        id: "REC_001",
        timestamp: "2024-01-20T10:30:00Z",
        action: "Lesson Booked",
        status: "completed",
        details: "Student booked 1-hour Spanish lesson",
        actor: "student",
        metadata: { amount: 25, duration: 60 },
      },
      {
        id: "REC_002",
        timestamp: "2024-01-20T10:31:00Z",
        action: "Payment Processed",
        status: "completed",
        details: "Payment of $25.00 processed successfully",
        actor: "system",
        metadata: { amount: 25 },
      },
      {
        id: "REC_003",
        timestamp: "2024-01-20T10:32:00Z",
        action: "Teacher Notified",
        status: "completed",
        details: "Teacher María García notified of new booking",
        actor: "system",
      },
      {
        id: "REC_004",
        timestamp: "2024-01-20T15:45:00Z",
        action: "Lesson Confirmed",
        status: "completed",
        details: "Teacher confirmed the lesson and provided meeting link",
        actor: "teacher",
      },
      {
        id: "REC_005",
        timestamp: "2024-01-22T09:00:00Z",
        action: "Materials Uploaded",
        status: "completed",
        details: "Teacher uploaded lesson materials and homework assignment",
        actor: "teacher",
      },
      {
        id: "REC_006",
        timestamp: "2024-01-24T20:00:00Z",
        action: "Reminder Sent",
        status: "completed",
        details: "24-hour lesson reminder sent to student and teacher",
        actor: "system",
      },
      {
        id: "REC_007",
        timestamp: "2024-01-25T13:30:00Z",
        action: "Pre-lesson Check",
        status: "pending",
        details: "30-minute reminder and technical check",
        actor: "system",
      },
      {
        id: "REC_008",
        timestamp: "2024-01-25T14:00:00Z",
        action: "Lesson Start",
        status: "pending",
        details: "Scheduled lesson start time",
        actor: "system",
      },
    ];
  }
}

export const lessonDetailsService = new LessonDetailsService();
