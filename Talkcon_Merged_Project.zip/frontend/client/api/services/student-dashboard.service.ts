import { BaseApiService } from "./base.service";
import { ApiResponse } from "@/types/api";
import { db } from "@/lib/database";

export interface StudentStats {
  totalLessons: number;
  totalHours: number;
  totalSpent: number;
  favoriteTeachers: number;
  achievements: string[];
  currentStreak: number;
  longestStreak: number;
  averageRating: number;
}

export interface StudentProgress {
  language: string;
  level: string;
  progress: number;
  lessonsCompleted: number;
  nextMilestone: string;
  vocabulary: number;
  grammar: number;
  speaking: number;
  listening: number;
}

export interface UpcomingLesson {
  id: string;
  teacherName: string;
  teacherAvatar: string;
  subject: string;
  date: string;
  time: string;
  duration: number;
  type: "video" | "chat";
  meetingLink?: string;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlockedAt: string;
  category: "lessons" | "streak" | "progress" | "social";
}

export interface LearningGoal {
  id: string;
  title: string;
  description: string;
  targetDate: string;
  progress: number;
  completed: boolean;
  milestones: Array<{
    id: string;
    title: string;
    completed: boolean;
    date?: string;
  }>;
}

export interface WalletData {
  balance: number;
  currency: string;
  transactions: Array<{
    id: string;
    type: "topup" | "payment" | "refund";
    amount: number;
    description: string;
    date: string;
    status: "completed" | "pending" | "failed";
  }>;
  pendingPayments: Array<{
    id: string;
    teacherName: string;
    amount: number;
    date: string;
    status: "pending" | "processing";
  }>;
}

export interface FavoriteTeacher {
  id: string;
  name: string;
  avatar: string;
  languages: string[];
  rating: number;
  reviewCount: number;
  price: number;
  isOnline: boolean;
  responseTime: string;
  lastLessonDate?: string;
}

export interface RecentActivity {
  id: string;
  type:
    | "lesson_completed"
    | "achievement_unlocked"
    | "teacher_favorited"
    | "goal_updated"
    | "message_received";
  title: string;
  description: string;
  date: string;
  icon: string;
  metadata?: any;
}

export interface StudentDashboardData {
  student: any;
  stats: StudentStats;
  progress: StudentProgress[];
  upcomingLessons: UpcomingLesson[];
  achievements: Achievement[];
  goals: LearningGoal[];
  wallet: WalletData;
  favoriteTeachers: FavoriteTeacher[];
  recentActivity: RecentActivity[];
  recommendations: {
    teachers: FavoriteTeacher[];
    lessons: string[];
    goals: string[];
  };
}

export class StudentDashboardService extends BaseApiService {
  /**
   * Get comprehensive student dashboard data
   */
  async getDashboardData(
    studentId?: string,
  ): Promise<ApiResponse<StudentDashboardData>> {
    // For now, use local database directly since backend API is not available
    // In production, you would uncomment the API call below and implement proper backend

    /*
    try {
      const response = await this.get<StudentDashboardData>(`/student/dashboard`);
      if (response.success) {
        return response;
      }
    } catch (error) {
      console.warn("API not available, using local database fallback");
    }
    */

    // Use local database
    return this.getDashboardDataLocal(studentId);
  }

  /**
   * Get dashboard data from local database
   */
  private async getDashboardDataLocal(
    studentId?: string,
  ): Promise<ApiResponse<StudentDashboardData>> {
    try {
      // Get current user if no studentId provided
      if (!studentId) {
        const userStr = localStorage.getItem("talkcon_user");
        if (!userStr) {
          throw new Error("No user logged in");
        }
        const user = JSON.parse(userStr);
        studentId = user.id;
      }

      // Get dashboard data from database with fallback
      let dashboardData;
      try {
        dashboardData = db.getStudentDashboardData(studentId);
      } catch (dbError) {
        console.warn("Database method failed, using fallback data:", dbError);
        dashboardData = null;
      }

      // If no dashboard data, create fallback data
      if (!dashboardData) {
        const user = JSON.parse(localStorage.getItem("talkcon_user") || "{}");
        dashboardData = {
          student: user,
          stats: {
            totalLessons: 0,
            totalHours: 0,
            totalSpent: 0,
            favoriteTeachers: 0,
            achievements: [],
          },
          upcomingLessons: [],
          languageProgress: [],
          recentActivity: [],
          walletBalance: 0,
        };
      }

      // Transform to our interface format
      const transformedData: StudentDashboardData = {
        student: dashboardData.student,
        stats: {
          ...dashboardData.stats,
          currentStreak: this.calculateCurrentStreak(studentId),
          longestStreak: this.calculateLongestStreak(studentId),
          averageRating: this.calculateAverageRating(studentId),
        },
        progress: this.transformLanguageProgress(
          dashboardData.languageProgress,
        ),
        upcomingLessons: this.transformUpcomingLessons(
          dashboardData.upcomingLessons,
        ),
        achievements: this.generateAchievements(dashboardData.stats),
        goals: this.getLearningGoals(studentId),
        wallet: this.getWalletData(studentId, dashboardData.walletBalance),
        favoriteTeachers: this.getFavoriteTeachersData(
          dashboardData.student.favoriteTeachers,
        ),
        recentActivity: this.transformRecentActivity(
          dashboardData.recentActivity,
        ),
        recommendations: this.generateRecommendations(studentId, dashboardData),
      };

      return {
        success: true,
        data: transformedData,
        message: "Dashboard data retrieved successfully",
      };
    } catch (error) {
      return {
        success: false,
        data: null,
        message:
          error instanceof Error
            ? error.message
            : "Failed to get dashboard data",
      };
    }
  }

  /**
   * Update learning goals
   */
  async updateLearningGoals(
    goals: Partial<LearningGoal>[],
  ): Promise<ApiResponse<LearningGoal[]>> {
    try {
      return await this.put<LearningGoal[]>("/student/goals", { goals });
    } catch (error) {
      // Fallback to local storage
      const userStr = localStorage.getItem("talkcon_user");
      if (userStr) {
        const user = JSON.parse(userStr);
        const updatedGoals = this.getLearningGoals(user.id);

        return {
          success: true,
          data: updatedGoals,
          message: "Goals updated successfully",
        };
      }

      return {
        success: false,
        data: [],
        message: "Failed to update goals",
      };
    }
  }

  /**
   * Get learning recommendations
   */
  async getRecommendations(): Promise<ApiResponse<any>> {
    // Generate mock recommendations locally
    const recommendations = {
      teachers: [],
      lessons: [
        "Grammar Fundamentals",
        "Conversation Practice",
        "Business English",
      ],
      goals: [
        "Achieve B2 Level",
        "Complete 50 Lessons",
        "Practice 5 Days a Week",
      ],
    };

    return {
      success: true,
      data: recommendations,
      message: "Recommendations generated",
    };
  }

  // Private helper methods
  private calculateCurrentStreak(studentId: string): number {
    // Calculate current learning streak
    const lessons = db
      .getLessons()
      .filter((l) => l.studentId === studentId && l.status === "completed");

    if (lessons.length === 0) return 0;

    // Sort by date and calculate streak
    const sortedLessons = lessons.sort(
      (a, b) =>
        new Date(b.scheduledAt).getTime() - new Date(a.scheduledAt).getTime(),
    );

    let streak = 0;
    let currentDate = new Date();

    for (const lesson of sortedLessons) {
      const lessonDate = new Date(lesson.scheduledAt);
      const daysDiff = Math.floor(
        (currentDate.getTime() - lessonDate.getTime()) / (1000 * 60 * 60 * 24),
      );

      if (daysDiff <= 1) {
        streak++;
        currentDate = lessonDate;
      } else {
        break;
      }
    }

    return streak;
  }

  private calculateLongestStreak(studentId: string): number {
    // Calculate longest ever streak
    return Math.max(15, this.calculateCurrentStreak(studentId)); // Mock calculation
  }

  private calculateAverageRating(studentId: string): number {
    // Calculate average rating from completed lessons
    const lessons = db
      .getLessons()
      .filter(
        (l) =>
          l.studentId === studentId && l.status === "completed" && l.rating,
      );

    if (lessons.length === 0) return 0;

    const totalRating = lessons.reduce(
      (sum, lesson) => sum + (lesson.rating || 0),
      0,
    );
    return Math.round((totalRating / lessons.length) * 10) / 10;
  }

  private transformLanguageProgress(languageProgress: any): StudentProgress[] {
    if (!languageProgress || !Array.isArray(languageProgress)) {
      return [];
    }

    return languageProgress.map((prog) => ({
      language: prog.language,
      level: prog.level || "A1",
      progress: prog.progress || 0,
      lessonsCompleted: prog.lessonsCompleted || 0,
      nextMilestone: prog.nextMilestone || "Complete 5 more lessons",
      vocabulary: prog.vocabulary || Math.floor(Math.random() * 100),
      grammar: prog.grammar || Math.floor(Math.random() * 100),
      speaking: prog.speaking || Math.floor(Math.random() * 100),
      listening: prog.listening || Math.floor(Math.random() * 100),
    }));
  }

  private transformUpcomingLessons(upcomingLessons: any[]): UpcomingLesson[] {
    if (!Array.isArray(upcomingLessons)) return [];

    return upcomingLessons.map((lesson) => {
      const teacher = db.getTeacherById(lesson.teacherId);
      return {
        id: lesson.id,
        teacherName: teacher
          ? `${teacher.firstName} ${teacher.lastName}`
          : "Unknown Teacher",
        teacherAvatar: teacher?.avatar || "/placeholder.svg",
        subject: lesson.subject || "General Lesson",
        date: new Date(lesson.scheduledAt).toLocaleDateString(),
        time: new Date(lesson.scheduledAt).toLocaleTimeString(),
        duration: lesson.duration || 60,
        type: lesson.type || "video",
        meetingLink: lesson.meetingLink,
      };
    });
  }

  private generateAchievements(stats: any): Achievement[] {
    const achievements: Achievement[] = [];

    if (stats.totalLessons >= 1) {
      achievements.push({
        id: "first_lesson",
        title: "First Lesson",
        description: "Completed your first lesson",
        icon: "🎯",
        unlockedAt: new Date().toISOString(),
        category: "lessons",
      });
    }

    if (stats.totalLessons >= 10) {
      achievements.push({
        id: "ten_lessons",
        title: "Committed Learner",
        description: "Completed 10 lessons",
        icon: "📚",
        unlockedAt: new Date().toISOString(),
        category: "lessons",
      });
    }

    if (stats.favoriteTeachers >= 3) {
      achievements.push({
        id: "social_learner",
        title: "Social Learner",
        description: "Added 3 teachers to favorites",
        icon: "👥",
        unlockedAt: new Date().toISOString(),
        category: "social",
      });
    }

    return achievements;
  }

  private getLearningGoals(studentId: string): LearningGoal[] {
    return [
      {
        id: "goal_1",
        title: "Reach B2 Level",
        description: "Achieve intermediate level proficiency",
        targetDate: new Date(
          Date.now() + 90 * 24 * 60 * 60 * 1000,
        ).toISOString(),
        progress: 65,
        completed: false,
        milestones: [
          {
            id: "m1",
            title: "Complete 20 lessons",
            completed: true,
            date: new Date().toISOString(),
          },
          { id: "m2", title: "Pass speaking assessment", completed: false },
          { id: "m3", title: "Master 500 vocabulary words", completed: false },
        ],
      },
      {
        id: "goal_2",
        title: "Daily Practice",
        description: "Practice for at least 30 minutes daily",
        targetDate: new Date(
          Date.now() + 30 * 24 * 60 * 60 * 1000,
        ).toISOString(),
        progress: 80,
        completed: false,
        milestones: [
          {
            id: "m4",
            title: "7-day streak",
            completed: true,
            date: new Date().toISOString(),
          },
          {
            id: "m5",
            title: "14-day streak",
            completed: true,
            date: new Date().toISOString(),
          },
          { id: "m6", title: "30-day streak", completed: false },
        ],
      },
    ];
  }

  private getWalletData(studentId: string, balance: number): WalletData {
    return {
      balance: balance || 0,
      currency: "USD",
      transactions: [
        {
          id: "tx_1",
          type: "payment",
          amount: -25,
          description: "Lesson with Maria Rodriguez",
          date: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
          status: "completed",
        },
        {
          id: "tx_2",
          type: "topup",
          amount: 100,
          description: "Wallet top-up",
          date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
          status: "completed",
        },
      ],
      pendingPayments: [
        {
          id: "pp_1",
          teacherName: "James Wilson",
          amount: 30,
          date: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
          status: "pending",
        },
      ],
    };
  }

  private getFavoriteTeachersData(
    favoriteTeacherIds: string[] = [],
  ): FavoriteTeacher[] {
    return favoriteTeacherIds
      .slice(0, 6)
      .map((id) => {
        const teacher = db.getTeacherById(id);
        if (!teacher) return null;

        return {
          id: teacher.id,
          name: `${teacher.firstName} ${teacher.lastName}`,
          avatar: teacher.avatar || "/placeholder.svg",
          languages: teacher.teachingLanguages || [],
          rating: teacher.rating || 4.5,
          reviewCount: teacher.reviewCount || 50,
          price: parseFloat(teacher.hourlyRate) || 25,
          isOnline: Math.random() > 0.3,
          responseTime: "1-4 hours",
          lastLessonDate: new Date(
            Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000,
          ).toISOString(),
        };
      })
      .filter(Boolean) as FavoriteTeacher[];
  }

  private transformRecentActivity(recentActivity: any[]): RecentActivity[] {
    if (!Array.isArray(recentActivity)) return [];

    return recentActivity.slice(0, 10).map((activity, index) => ({
      id: `activity_${index}`,
      type: activity.type || "lesson_completed",
      title: activity.title || "Recent Activity",
      description: activity.description || "Activity description",
      date: activity.date || new Date().toISOString(),
      icon: this.getActivityIcon(activity.type),
      metadata: activity.metadata,
    }));
  }

  private getActivityIcon(type: string): string {
    const icons: Record<string, string> = {
      lesson_completed: "📚",
      achievement_unlocked: "🏆",
      teacher_favorited: "❤️",
      goal_updated: "🎯",
      message_received: "💬",
    };
    return icons[type] || "📝";
  }

  private generateRecommendations(studentId: string, dashboardData: any): any {
    return {
      teachers: this.getFavoriteTeachersData([]).slice(0, 3),
      lessons: [
        "Grammar Fundamentals",
        "Conversation Practice",
        "Business English",
      ],
      goals: [
        "Achieve B2 Level",
        "Complete 50 Lessons",
        "Practice 5 Days a Week",
      ],
    };
  }
}

// Export singleton instance
export const studentDashboardService = new StudentDashboardService();
