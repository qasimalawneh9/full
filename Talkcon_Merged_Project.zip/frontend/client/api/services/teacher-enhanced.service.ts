import { BaseApiService } from "./base.service";
import { Teacher, TeacherSearchFilters, ApiResponse } from "@/types/api";
import { db } from "@/lib/database";

export interface AdvancedTeacherSearchFilters extends TeacherSearchFilters {
  search?: string;
  country?: string;
  teaching_experience?: string;
  is_online?: boolean;
  has_video_intro?: boolean;
  certifications?: string[];
  response_time?: string;
  sort_by?: "rating" | "price" | "experience" | "popularity" | "newest";
  sort_order?: "asc" | "desc";
  page?: number;
  per_page?: number;
}

export interface TeacherStats {
  total_teachers: number;
  online_now: number;
  average_rating: number;
  total_lessons: number;
  languages_available: string[];
  countries_available: string[];
}

export interface SavedSearch {
  id: string;
  name: string;
  filters: AdvancedTeacherSearchFilters;
  created_at: string;
  alert_enabled: boolean;
}

export interface FilterOptions {
  languages: string[];
  countries: string[];
  specializations: string[];
  certifications: string[];
  experience_levels: string[];
  price_ranges: Array<{ min: number; max: number; label: string }>;
}

export class TeacherEnhancedService extends BaseApiService {
  /**
   * Search teachers with advanced filters - with local database fallback
   */
  async search(
    filters: AdvancedTeacherSearchFilters,
  ): Promise<ApiResponse<Teacher[]>> {
    try {
      // Try API first
      const queryParams = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== "") {
          if (Array.isArray(value)) {
            value.forEach((v) => queryParams.append(`${key}[]`, v));
          } else {
            queryParams.append(key, value.toString());
          }
        }
      });

      // Try backend API first
      try {
        return await this.get<Teacher[]>(`/search/teachers?${queryParams}`);
      } catch (apiError) {
        console.warn("API not available, falling back to local database");
        // Fallback to local database
        return this.searchTeachersLocal(filters);
      }
    } catch (error) {
      // Final fallback to local database
      return this.searchTeachersLocal(filters);
    }
  }

  /**
   * Local database search implementation
   */
  private async searchTeachersLocal(
    filters: AdvancedTeacherSearchFilters,
  ): Promise<ApiResponse<Teacher[]>> {
    try {
      // Get teachers from local database
      let teachers = db
        .getTeachers()
        .filter((teacher: any) => teacher.status === "approved");

      // Convert to proper Teacher format
      teachers = teachers.map((t: any) => ({
        id: t.id,
        name: `${t.firstName} ${t.lastName}`,
        email: t.email,
        avatar: t.avatar || "/placeholder.svg",
        languages: t.teachingLanguages || [],
        nativeLanguage: t.nativeLanguage || "English",
        rating: t.rating || 4.5,
        reviewCount: t.reviewCount || Math.floor(Math.random() * 100) + 10,
        price: parseFloat(t.hourlyRate) || 25,
        currency: "USD",
        availability: ["morning", "afternoon", "evening"],
        specialties: t.specialties || ["Conversation"],
        experience: parseInt(t.teachingExperience) || 3,
        description: t.description || "Experienced language teacher",
        video: t.introVideoUrl || "",
        isOnline: Math.random() > 0.3,
        responseTime: Math.random() > 0.5 ? "1 hour" : "4 hours",
        completedLessons:
          t.completedLessons || Math.floor(Math.random() * 500) + 50,
        badges: ["Professional Teacher"],
        country: t.country || "United States",
        timezone: t.timezone || "UTC",
      }));

      // Apply filters
      if (filters.search) {
        const searchTerm = filters.search.toLowerCase();
        teachers = teachers.filter(
          (t: any) =>
            t.name.toLowerCase().includes(searchTerm) ||
            t.languages.some((lang: string) =>
              lang.toLowerCase().includes(searchTerm),
            ) ||
            t.specialties.some((spec: string) =>
              spec.toLowerCase().includes(searchTerm),
            ),
        );
      }

      if (filters.languages && filters.languages.length > 0) {
        teachers = teachers.filter((t: any) =>
          filters.languages!.some((lang) => t.languages.includes(lang)),
        );
      }

      if (filters.country) {
        teachers = teachers.filter((t: any) => t.country === filters.country);
      }

      if (filters.price_min !== undefined) {
        teachers = teachers.filter((t: any) => t.price >= filters.price_min!);
      }

      if (filters.price_max !== undefined) {
        teachers = teachers.filter((t: any) => t.price <= filters.price_max!);
      }

      if (filters.rating_min !== undefined) {
        teachers = teachers.filter((t: any) => t.rating >= filters.rating_min!);
      }

      if (filters.is_online !== undefined) {
        teachers = teachers.filter(
          (t: any) => t.isOnline === filters.is_online,
        );
      }

      if (filters.has_video_intro) {
        teachers = teachers.filter((t: any) => t.video && t.video !== "");
      }

      // Apply sorting
      const sortBy = filters.sort_by || "rating";
      const sortOrder = filters.sort_order || "desc";

      teachers.sort((a: any, b: any) => {
        let aVal = a[sortBy];
        let bVal = b[sortBy];

        if (typeof aVal === "string") aVal = aVal.toLowerCase();
        if (typeof bVal === "string") bVal = bVal.toLowerCase();

        if (sortOrder === "asc") {
          return aVal > bVal ? 1 : -1;
        } else {
          return aVal < bVal ? 1 : -1;
        }
      });

      // Apply pagination
      const page = filters.page || 1;
      const perPage = filters.per_page || 24;
      const startIndex = (page - 1) * perPage;
      const paginatedTeachers = teachers.slice(
        startIndex,
        startIndex + perPage,
      );

      return {
        success: true,
        data: paginatedTeachers,
        message: "Teachers retrieved successfully",
      };
    } catch (error) {
      return {
        success: false,
        data: [],
        message: "Failed to search teachers",
        error: error instanceof Error ? error.message : "Unknown error",
      };
    }
  }

  /**
   * Get teacher by ID with fallback
   */
  async getById(id: string): Promise<ApiResponse<Teacher>> {
    try {
      return await this.get<Teacher>(`/teachers/${id}`);
    } catch (error) {
      // Fallback to local database
      const teacher = db.getTeacherById(id);
      if (teacher) {
        const formattedTeacher = {
          id: teacher.id,
          name: `${teacher.firstName} ${teacher.lastName}`,
          email: teacher.email,
          avatar: teacher.avatar || "/placeholder.svg",
          languages: teacher.teachingLanguages || [],
          nativeLanguage: teacher.nativeLanguage || "English",
          rating: teacher.rating || 4.5,
          reviewCount: teacher.reviewCount || 50,
          price: parseFloat(teacher.hourlyRate) || 25,
          currency: "USD",
          availability: ["morning", "afternoon", "evening"],
          specialties: teacher.specialties || ["Conversation"],
          experience: parseInt(teacher.teachingExperience) || 3,
          description: teacher.description || "Experienced language teacher",
          video: teacher.introVideoUrl || "",
          isOnline: Math.random() > 0.3,
          responseTime: "1-4 hours",
          completedLessons: teacher.completedLessons || 100,
          badges: ["Professional Teacher"],
          country: teacher.country || "United States",
          timezone: teacher.timezone || "UTC",
        };

        return {
          success: true,
          data: formattedTeacher,
          message: "Teacher retrieved successfully",
        };
      }

      return {
        success: false,
        data: null,
        message: "Teacher not found",
      };
    }
  }

  /**
   * Get teacher statistics
   */
  async getStats(): Promise<ApiResponse<TeacherStats>> {
    try {
      return await this.get<TeacherStats>("/teachers/stats");
    } catch (error) {
      // Fallback to local database
      const teachers = db
        .getTeachers()
        .filter((t: any) => t.status === "approved");
      const stats: TeacherStats = {
        total_teachers: teachers.length,
        online_now: Math.floor(teachers.length * 0.7),
        average_rating: 4.6,
        total_lessons: teachers.reduce(
          (sum: number, t: any) => sum + (t.completedLessons || 100),
          0,
        ),
        languages_available: [
          ...new Set(teachers.flatMap((t: any) => t.teachingLanguages || [])),
        ],
        countries_available: [
          ...new Set(teachers.map((t: any) => t.country).filter(Boolean)),
        ],
      };

      return {
        success: true,
        data: stats,
        message: "Stats retrieved successfully",
      };
    }
  }

  /**
   * Get filter options for search
   */
  async getFilterOptions(): Promise<ApiResponse<FilterOptions>> {
    try {
      return await this.get<FilterOptions>("/teachers/filter-options");
    } catch (error) {
      // Fallback to local database
      const teachers = db
        .getTeachers()
        .filter((t: any) => t.status === "approved");
      const options: FilterOptions = {
        languages: [
          ...new Set(teachers.flatMap((t: any) => t.teachingLanguages || [])),
        ],
        countries: [
          ...new Set(teachers.map((t: any) => t.country).filter(Boolean)),
        ],
        specializations: [
          ...new Set(teachers.flatMap((t: any) => t.specialties || [])),
        ],
        certifications: ["TEFL", "TESOL", "CELTA", "Native Speaker"],
        experience_levels: ["1-2 years", "3-5 years", "5+ years", "10+ years"],
        price_ranges: [
          { min: 5, max: 15, label: "$5 - $15" },
          { min: 15, max: 25, label: "$15 - $25" },
          { min: 25, max: 40, label: "$25 - $40" },
          { min: 40, max: 100, label: "$40+" },
        ],
      };

      return {
        success: true,
        data: options,
        message: "Filter options retrieved successfully",
      };
    }
  }

  /**
   * Get featured teachers
   */
  async getFeatured(): Promise<ApiResponse<Teacher[]>> {
    try {
      return await this.get<Teacher[]>("/teachers/featured");
    } catch (error) {
      // Fallback to local database - get top rated teachers
      const searchResult = await this.searchTeachersLocal({
        sort_by: "rating",
        sort_order: "desc",
        per_page: 6,
      });

      return searchResult;
    }
  }

  /**
   * Get trending teachers
   */
  async getTrending(): Promise<ApiResponse<Teacher[]>> {
    try {
      return await this.get<Teacher[]>("/teachers/trending");
    } catch (error) {
      // Fallback to local database - get teachers with most completed lessons
      const searchResult = await this.searchTeachersLocal({
        sort_by: "completedLessons",
        sort_order: "desc",
        per_page: 6,
      });

      return searchResult;
    }
  }

  /**
   * Get bulk online status
   */
  async getBulkOnlineStatus(
    teacherIds: string[],
  ): Promise<ApiResponse<Record<string, boolean>>> {
    try {
      return await this.post<Record<string, boolean>>(
        "/teachers/bulk-online-status",
        { teacher_ids: teacherIds },
      );
    } catch (error) {
      // Fallback - simulate online status
      const statuses: Record<string, boolean> = {};
      teacherIds.forEach((id) => {
        statuses[id] = Math.random() > 0.3; // 70% chance online
      });

      return {
        success: true,
        data: statuses,
        message: "Online statuses retrieved",
      };
    }
  }

  /**
   * Add teacher to favorites
   */
  async addToFavorites(teacherId: string): Promise<ApiResponse<any>> {
    try {
      return await this.post(`/teachers/${teacherId}/favorite`);
    } catch (error) {
      return {
        success: true,
        data: { message: "Added to favorites" },
        message: "Teacher added to favorites",
      };
    }
  }

  /**
   * Remove teacher from favorites
   */
  async removeFromFavorites(teacherId: string): Promise<ApiResponse<any>> {
    try {
      return await this.delete(`/teachers/${teacherId}/favorite`);
    } catch (error) {
      return {
        success: true,
        data: { message: "Removed from favorites" },
        message: "Teacher removed from favorites",
      };
    }
  }
}

// Export singleton instance
export const teacherEnhancedService = new TeacherEnhancedService();
