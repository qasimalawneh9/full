import React from "react";
import { Footer } from "@/components/ui/footer";

interface PageWrapperProps {
  children: React.ReactNode;
  className?: string;
  showFooter?: boolean;
}

export function PageWrapper({
  children,
  className = "",
  showFooter = true,
}: PageWrapperProps) {
  return (
    <div className={`min-h-screen flex flex-col ${className}`}>
      {/* Main content area - grows to fill available space */}
      <div className="flex-1">{children}</div>

      {/* Footer - always at bottom */}
      {showFooter && <Footer />}
    </div>
  );
}
