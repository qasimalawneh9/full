import React, { createContext, useContext, useState, ReactNode } from "react";

export type Language = "en" | "es" | "fr" | "de" | "zh" | "ar";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(
  undefined,
);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
};

const translations = {
  en: {
    // Navigation
    "nav.home": "Home",
    "nav.teachers": "Teachers",
    "nav.community": "Community",
    "nav.howItWorks": "How it Works",
    "nav.pricing": "Pricing",
    "nav.languages": "Languages",
    "nav.help": "Help",
    "nav.contact": "Contact",
    "nav.about": "About",
    "nav.becomeTeacher": "Become a Teacher",
    "nav.login": "Login",
    "nav.signup": "Sign up",
    "nav.dashboard": "Dashboard",
    "nav.settings": "Settings",
    "nav.messages": "Messages",
    "nav.lessons": "Lessons",

    // Common buttons
    "button.getStarted": "Get Started",
    "button.learnMore": "Learn More",
    "button.bookTrial": "Book Trial Lesson",
    "button.viewProfile": "View Profile",
    "button.bookLesson": "Book Lesson",
    "button.contactTeacher": "Contact Teacher",

    // Homepage
    "hero.title": "Learn Languages with Native Speakers",
    "hero.subtitle":
      "Connect with qualified teachers for personalized 1-on-1 lessons. Start speaking confidently today.",
    "hero.cta": "Find Your Teacher",
    "feature.whyChoose": "Why choose Talkcon?",
    "feature.title1": "Expert Native Teachers",
    "feature.desc1": "Learn from certified teachers and native speakers",
    "feature.title2": "Flexible Scheduling",
    "feature.desc2": "Book lessons that fit your schedule, anytime",
    "feature.title3": "Affordable Prices",
    "feature.desc3": "Quality language learning at competitive rates",

    // Footer
    "footer.copyright":
      "© 2024 Talkcon. All rights reserved. | Made with ❤️ for language learners worldwide.",

    // Auth
    "auth.login.title": "Welcome back",
    "auth.login.subtitle": "Login to your account to continue learning",
    "auth.signup.title": "Create your account",
    "auth.signup.subtitle": "Join thousands of language learners",
    "auth.signup.userType": "How do you want to use Talkcon?",
    "auth.email": "Email",
    "auth.password": "Password",
    "auth.name": "Name",
    "auth.forgotPassword": "Forgot password?",

    // Language selector
    "language.select": "Language",
    "language.change": "Change Language",

    // Teacher Pages
    "teacher.findTeachers": "Find Your Perfect Teacher",
    "teacher.searchPlaceholder": "Search by name, language, or specialization",
    "teacher.filters": "Filters",
    "teacher.experience": "Experience",
    "teacher.hourlyRate": "Hourly Rate",
    "teacher.availability": "Availability",
    "teacher.specializations": "Specializations",
    "teacher.viewProfile": "View Profile",
    "teacher.bookTrial": "Book Trial",
    "teacher.bookLesson": "Book Lesson",

    // Dashboard
    "dashboard.welcome": "Welcome",
    "dashboard.myLessons": "My Lessons",
    "dashboard.upcomingLessons": "Upcoming Lessons",
    "dashboard.completedLessons": "Completed Lessons",
    "dashboard.totalHours": "Total Hours",
    "dashboard.favoriteTeachers": "Favorite Teachers",
    "dashboard.recentActivity": "Recent Activity",

    // Lessons
    "lesson.upcoming": "Upcoming",
    "lesson.completed": "Completed",
    "lesson.cancelled": "Cancelled",
    "lesson.duration": "Duration",
    "lesson.teacher": "Teacher",
    "lesson.date": "Date",
    "lesson.time": "Time",
    "lesson.status": "Status",

    // Messaging
    "message.newMessage": "New Message",
    "message.sendMessage": "Send Message",
    "message.typeMessage": "Type your message...",
    "message.noMessages": "No messages yet",
    "message.startConversation": "Start a conversation",

    // Common
    "common.search": "Search",
    "common.filter": "Filter",
    "common.clear": "Clear",
    "common.save": "Save",
    "common.cancel": "Cancel",
    "common.delete": "Delete",
    "common.edit": "Edit",
    "common.loading": "Loading...",
    "common.error": "Error",
    "common.success": "Success",

    // Status
    "status.online": "Online",
    "status.offline": "Offline",
    "status.away": "Away",
    "status.busy": "Busy",

    // Pages
    "page.home": "Home",
    "page.teachers": "Teachers",
    "page.community": "Community",
    "page.howItWorks": "How it Works",
    "page.pricing": "Pricing",
    "page.languages": "Languages",
    "page.help": "Help",
    "page.contact": "Contact",
    "page.about": "About",
    "page.login": "Login",
    "page.signup": "Sign Up",
    "page.profile": "Profile",
    "page.dashboard": "Dashboard",
    "page.settings": "Settings",
    "page.messages": "Messages",
    "page.lessons": "Lessons",
  },

  es: {
    // Basic translations for Spanish
    "nav.home": "Inicio",
    "nav.teachers": "Profesores",
    "nav.community": "Comunidad",
    "nav.login": "Iniciar Sesión",
    "nav.signup": "Registrarse",
    "auth.login.title": "Bienvenido de vuelta",
    "auth.login.subtitle": "Inicia sesión en tu cuenta para continuar",
    "dashboard.welcome": "Bienvenido",
  },

  fr: {
    // Basic translations for French
    "nav.home": "Accueil",
    "nav.teachers": "Professeurs",
    "nav.community": "Communauté",
    "nav.login": "Se Connecter",
    "nav.signup": "S'inscrire",
    "auth.login.title": "Bon retour",
    "auth.login.subtitle": "Connectez-vous à votre compte pour continuer",
    "dashboard.welcome": "Bienvenue",
  },

  de: {
    // Basic translations for German
    "nav.home": "Start",
    "nav.teachers": "Lehrer",
    "nav.community": "Gemeinschaft",
    "nav.login": "Anmelden",
    "nav.signup": "Registrieren",
    "auth.login.title": "Willkommen zurück",
    "auth.login.subtitle":
      "Melden Sie sich bei Ihrem Konto an, um fortzufahren",
    "dashboard.welcome": "Willkommen",
  },

  zh: {
    // Basic translations for Chinese
    "nav.home": "首页",
    "nav.teachers": "老师",
    "nav.community": "社区",
    "nav.login": "登录",
    "nav.signup": "注册",
    "auth.login.title": "欢迎回来",
    "auth.login.subtitle": "登录您的账户以继续",
    "dashboard.welcome": "欢迎",
  },

  ar: {
    // Basic translations for Arabic
    "nav.home": "الرئيسية",
    "nav.teachers": "المعلمو��",
    "nav.community": "المجتمع",
    "nav.login": "تسجيل الدخول",
    "nav.signup": "إنشاء حساب",
    "auth.login.title": "أهلاً بعودتك",
    "auth.login.subtitle": "سجل دخولك للمتابعة",
    "dashboard.welcome": "أهلاً وسهلاً",
  },
};

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({
  children,
}) => {
  const [language, setLanguage] = useState<Language>("en");

  const t = (key: string): string => {
    const languageTranslations = translations[language];
    return (
      languageTranslations[key as keyof typeof languageTranslations] || key
    );
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};
