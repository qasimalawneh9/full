import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Navbar } from "@/components/ui/navbar";
import { Footer } from "@/components/ui/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Search,
  Star,
  Clock,
  Video,
  MessageCircle,
  Calendar,
  Globe,
  Filter,
  Heart,
  Play,
  Award,
  Users,
  BookOpen,
  Zap,
  ChevronDown,
  Grid,
  List,
  SlidersHorizontal,
  MapPin,
} from "lucide-react";
import { db } from "@/lib/database";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";

interface Teacher {
  id: string;
  name: string;
  email: string;
  avatar: string;
  languages: string[];
  nativeLanguage: string;
  rating: number;
  reviewCount: number;
  price: number;
  currency: string;
  availability: string[];
  specialties: string[];
  experience: number;
  description: string;
  video: string;
  isOnline: boolean;
  responseTime: string;
  completedLessons: number;
  badges: string[];
  country: string;
  timezone: string;
}

interface SearchFilters {
  search: string;
  language: string;
  country: string;
  priceMin: number;
  priceMax: number;
  rating: number;
  onlineOnly: boolean;
  hasVideo: boolean;
  sortBy: "rating" | "price" | "experience" | "newest";
}

export default function FindYourTeacher() {
  const { user } = useAuth();
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [filteredTeachers, setFilteredTeachers] = useState<Teacher[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [favorites, setFavorites] = useState<string[]>([]);

  const [filters, setFilters] = useState<SearchFilters>({
    search: "",
    language: "",
    country: "",
    priceMin: 5,
    priceMax: 100,
    rating: 0,
    onlineOnly: false,
    hasVideo: false,
    sortBy: "rating",
  });

  const [stats, setStats] = useState({
    total: 0,
    online: 0,
    languages: [] as string[],
    countries: [] as string[],
  });

  useEffect(() => {
    loadTeachers();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [teachers, filters]);

  const loadTeachers = async () => {
    setLoading(true);
    try {
      // Get approved teachers from database
      const dbTeachers = db
        .getTeachers()
        .filter((t: any) => t.status === "approved");

      // Transform to our Teacher interface
      const transformedTeachers: Teacher[] = dbTeachers.map((t: any) => ({
        id: t.id,
        name: `${t.firstName} ${t.lastName}`,
        email: t.email,
        avatar: t.avatar || "/placeholder.svg",
        languages: t.teachingLanguages || [],
        nativeLanguage: t.nativeLanguage || "English",
        rating: t.rating || 4.0 + Math.random() * 1.0, // 4.0-5.0
        reviewCount: t.reviewCount || Math.floor(Math.random() * 200) + 20,
        price: parseFloat(t.hourlyRate) || 25,
        currency: "USD",
        availability: ["morning", "afternoon", "evening"],
        specialties: t.specialties || ["Conversation"],
        experience: parseInt(t.teachingExperience) || 3,
        description:
          t.description ||
          "Experienced language teacher passionate about helping students achieve their goals.",
        video: t.introVideoUrl || "",
        isOnline: Math.random() > 0.3, // 70% online
        responseTime: Math.random() > 0.5 ? "1 hour" : "4 hours",
        completedLessons:
          t.completedLessons || Math.floor(Math.random() * 500) + 50,
        badges: [
          "Professional Teacher",
          ...(t.rating > 4.7 ? ["Top Rated"] : []),
        ],
        country: t.country || "United States",
        timezone: t.timezone || "UTC",
      }));

      setTeachers(transformedTeachers);

      // Calculate stats
      const uniqueLanguages = [
        ...new Set(transformedTeachers.flatMap((t) => t.languages)),
      ];
      const uniqueCountries = [
        ...new Set(transformedTeachers.map((t) => t.country)),
      ];
      const onlineCount = transformedTeachers.filter((t) => t.isOnline).length;

      setStats({
        total: transformedTeachers.length,
        online: onlineCount,
        languages: uniqueLanguages,
        countries: uniqueCountries,
      });
    } catch (error) {
      console.error("Failed to load teachers:", error);
      toast({
        title: "Error",
        description: "Failed to load teachers. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...teachers];

    // Search filter
    if (filters.search) {
      const searchTerm = filters.search.toLowerCase();
      filtered = filtered.filter(
        (t) =>
          t.name.toLowerCase().includes(searchTerm) ||
          t.languages.some((lang) => lang.toLowerCase().includes(searchTerm)) ||
          t.specialties.some((spec) =>
            spec.toLowerCase().includes(searchTerm),
          ) ||
          t.country.toLowerCase().includes(searchTerm),
      );
    }

    // Language filter
    if (filters.language) {
      filtered = filtered.filter((t) => t.languages.includes(filters.language));
    }

    // Country filter
    if (filters.country) {
      filtered = filtered.filter((t) => t.country === filters.country);
    }

    // Price range filter
    filtered = filtered.filter(
      (t) => t.price >= filters.priceMin && t.price <= filters.priceMax,
    );

    // Rating filter
    if (filters.rating > 0) {
      filtered = filtered.filter((t) => t.rating >= filters.rating);
    }

    // Online only filter
    if (filters.onlineOnly) {
      filtered = filtered.filter((t) => t.isOnline);
    }

    // Has video filter
    if (filters.hasVideo) {
      filtered = filtered.filter((t) => t.video && t.video !== "");
    }

    // Sorting
    filtered.sort((a, b) => {
      switch (filters.sortBy) {
        case "price":
          return a.price - b.price;
        case "experience":
          return b.experience - a.experience;
        case "newest":
          return Math.random() - 0.5; // Random for demo
        case "rating":
        default:
          return b.rating - a.rating;
      }
    });

    setFilteredTeachers(filtered);
  };

  const toggleFavorite = (teacherId: string) => {
    setFavorites((prev) =>
      prev.includes(teacherId)
        ? prev.filter((id) => id !== teacherId)
        : [...prev, teacherId],
    );

    toast({
      title: favorites.includes(teacherId)
        ? "Removed from favorites"
        : "Added to favorites",
      description: "Your favorites have been updated.",
    });
  };

  const handleBookingClick = (teacher: Teacher) => {
    if (!user) {
      toast({
        title: "Login Required",
        description: "Please login to book a lesson with this teacher.",
        variant: "destructive",
      });
      return;
    }

    // For demo, just show success
    toast({
      title: "Booking Request Sent",
      description: `Your booking request has been sent to ${teacher.name}. They will respond within ${teacher.responseTime}.`,
    });
  };

  const TeacherCard = ({
    teacher,
    isListView = false,
  }: {
    teacher: Teacher;
    isListView?: boolean;
  }) => (
    <Card
      className={`group hover:shadow-lg transition-all duration-300 ${isListView ? "flex" : ""}`}
    >
      <CardHeader className={`${isListView ? "flex-shrink-0 w-48" : ""}`}>
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Avatar className="h-12 w-12">
                <AvatarImage src={teacher.avatar} alt={teacher.name} />
                <AvatarFallback>
                  {teacher.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              {teacher.isOnline && (
                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full"></div>
              )}
            </div>
            <div>
              <h3 className="font-semibold text-lg">{teacher.name}</h3>
              <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                <MapPin className="h-3 w-3" />
                <span>{teacher.country}</span>
              </div>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => toggleFavorite(teacher.id)}
            className="p-1"
          >
            <Heart
              className={`h-4 w-4 ${favorites.includes(teacher.id) ? "fill-red-500 text-red-500" : ""}`}
            />
          </Button>
        </div>
      </CardHeader>

      <CardContent className={`${isListView ? "flex-1" : ""}`}>
        <div className="space-y-3">
          {/* Languages */}
          <div className="flex flex-wrap gap-1">
            {teacher.languages.slice(0, 3).map((lang) => (
              <Badge key={lang} variant="secondary" className="text-xs">
                {lang}
              </Badge>
            ))}
            {teacher.languages.length > 3 && (
              <Badge variant="outline" className="text-xs">
                +{teacher.languages.length - 3}
              </Badge>
            )}
          </div>

          {/* Rating and stats */}
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center space-x-2">
              <div className="flex items-center space-x-1">
                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                <span className="font-medium">{teacher.rating.toFixed(1)}</span>
                <span className="text-muted-foreground">
                  ({teacher.reviewCount})
                </span>
              </div>
            </div>
            <div className="flex items-center space-x-1">
              <Clock className="h-3 w-3 text-muted-foreground" />
              <span className="text-muted-foreground">
                {teacher.responseTime}
              </span>
            </div>
          </div>

          {/* Specialties */}
          <div className="text-sm text-muted-foreground">
            <span className="font-medium">Specialties:</span>{" "}
            {teacher.specialties.slice(0, 2).join(", ")}
            {teacher.specialties.length > 2 &&
              `, +${teacher.specialties.length - 2} more`}
          </div>

          {/* Description */}
          <p className="text-sm text-muted-foreground line-clamp-2">
            {teacher.description}
          </p>

          {/* Price and actions */}
          <div className="flex items-center justify-between pt-2">
            <div className="text-lg font-bold">
              ${teacher.price}
              <span className="text-sm font-normal text-muted-foreground">
                /hour
              </span>
            </div>
            <div className="flex space-x-2">
              {teacher.video && (
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Play className="h-3 w-3 mr-1" />
                      Video
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>
                        Introduction Video - {teacher.name}
                      </DialogTitle>
                    </DialogHeader>
                    <div className="aspect-video">
                      <iframe
                        src={teacher.video}
                        className="w-full h-full rounded-lg"
                        allowFullScreen
                      />
                    </div>
                  </DialogContent>
                </Dialog>
              )}
              <Button
                size="sm"
                onClick={() => handleBookingClick(teacher)}
                className="bg-primary text-primary-foreground hover:bg-primary/90"
              >
                Book Lesson
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-background">
      <Navbar isLoggedIn={!!user} userType={user?.type as any} />

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4">
            Find Your Perfect Language Teacher
          </h1>
          <p className="text-xl text-muted-foreground mb-6">
            Learn with qualified teachers from around the world
          </p>

          {/* Stats */}
          <div className="flex justify-center space-x-8 text-sm text-muted-foreground">
            <div className="flex items-center space-x-1">
              <Users className="h-4 w-4" />
              <span>{stats.total} Teachers</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span>{stats.online} Online Now</span>
            </div>
            <div className="flex items-center space-x-1">
              <Globe className="h-4 w-4" />
              <span>{stats.languages.length} Languages</span>
            </div>
          </div>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
              {/* Search */}
              <div className="lg:col-span-2">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search teachers, languages, or specialties..."
                    value={filters.search}
                    onChange={(e) =>
                      setFilters((prev) => ({
                        ...prev,
                        search: e.target.value,
                      }))
                    }
                    className="pl-10"
                  />
                </div>
              </div>

              {/* Language */}
              <Select
                value={filters.language}
                onValueChange={(value) =>
                  setFilters((prev) => ({ ...prev, language: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Any Language" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Any Language</SelectItem>
                  {stats.languages.map((lang) => (
                    <SelectItem key={lang} value={lang}>
                      {lang}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Country */}
              <Select
                value={filters.country}
                onValueChange={(value) =>
                  setFilters((prev) => ({ ...prev, country: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Any Country" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Any Country</SelectItem>
                  {stats.countries.map((country) => (
                    <SelectItem key={country} value={country}>
                      {country}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Additional Filters */}
            <div className="flex flex-wrap items-center gap-4 text-sm">
              <div className="flex items-center space-x-2">
                <label className="font-medium">Price:</label>
                <Input
                  type="number"
                  placeholder="Min"
                  value={filters.priceMin}
                  onChange={(e) =>
                    setFilters((prev) => ({
                      ...prev,
                      priceMin: parseInt(e.target.value) || 5,
                    }))
                  }
                  className="w-20"
                />
                <span>-</span>
                <Input
                  type="number"
                  placeholder="Max"
                  value={filters.priceMax}
                  onChange={(e) =>
                    setFilters((prev) => ({
                      ...prev,
                      priceMax: parseInt(e.target.value) || 100,
                    }))
                  }
                  className="w-20"
                />
              </div>

              <Select
                value={filters.sortBy}
                onValueChange={(value: any) =>
                  setFilters((prev) => ({ ...prev, sortBy: value }))
                }
              >
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rating">Highest Rated</SelectItem>
                  <SelectItem value="price">Lowest Price</SelectItem>
                  <SelectItem value="experience">Most Experience</SelectItem>
                  <SelectItem value="newest">Newest</SelectItem>
                </SelectContent>
              </Select>

              <div className="flex items-center space-x-4">
                <Button
                  variant={viewMode === "grid" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setViewMode("grid")}
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setViewMode("list")}
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        <div className="mb-4 text-sm text-muted-foreground">
          Showing {filteredTeachers.length} of {teachers.length} teachers
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
            <p className="mt-4 text-muted-foreground">Loading teachers...</p>
          </div>
        ) : filteredTeachers.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">
              No teachers found matching your criteria.
            </p>
            <Button
              variant="outline"
              onClick={() =>
                setFilters({
                  search: "",
                  language: "",
                  country: "",
                  priceMin: 5,
                  priceMax: 100,
                  rating: 0,
                  onlineOnly: false,
                  hasVideo: false,
                  sortBy: "rating",
                })
              }
              className="mt-4"
            >
              Clear Filters
            </Button>
          </div>
        ) : (
          <div
            className={
              viewMode === "grid"
                ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                : "space-y-4"
            }
          >
            {filteredTeachers.map((teacher) => (
              <TeacherCard
                key={teacher.id}
                teacher={teacher}
                isListView={viewMode === "list"}
              />
            ))}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
