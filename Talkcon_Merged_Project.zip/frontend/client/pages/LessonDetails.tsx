import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  Calendar,
  Clock,
  User,
  Video,
  FileText,
  Star,
  Download,
  MessageCircle,
  CheckCircle,
  AlertCircle,
  XCircle,
  Clock4,
} from "lucide-react";
import {
  lessonDetailsService,
  LessonDetails as LessonDetailsType,
  LessonRecord,
} from "@/api/services/lesson-details.service";

// Types are now imported from the service file

const LessonDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [lesson, setLesson] = useState<LessonDetailsType | null>(null);
  const [records, setRecords] = useState<LessonRecord[]>([]);
  const [loading, setLoading] = useState(true);

  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!id) {
      setError("Lesson ID is required");
      setLoading(false);
      return;
    }

    loadLessonData();
  }, [id]);

  const loadLessonData = async () => {
    setLoading(true);
    setError(null);

    try {
      // Load lesson details and history in parallel
      const [lessonResponse, historyResponse] = await Promise.all([
        lessonDetailsService.getLessonDetails(id!),
        lessonDetailsService.getLessonHistory(id!),
      ]);

      if (lessonResponse.success && lessonResponse.data) {
        setLesson(lessonResponse.data);
      } else {
        throw new Error(
          lessonResponse.message || "Failed to load lesson details",
        );
      }

      if (historyResponse.success && historyResponse.data) {
        setRecords(historyResponse.data.records);
      } else {
        console.warn("Failed to load lesson history:", historyResponse.message);
        setRecords([]); // Continue without history if it fails
      }
    } catch (err) {
      console.error("Error loading lesson data:", err);
      setError("Failed to load lesson details. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case "pending":
        return <Clock4 className="w-4 h-4 text-yellow-500" />;
      case "failed":
        return <XCircle className="w-4 h-4 text-red-500" />;
      case "in_progress":
        return <AlertCircle className="w-4 h-4 text-blue-500" />;
      default:
        return <Clock4 className="w-4 h-4 text-gray-400" />;
    }
  };

  const formatDateTime = (dateStr: string, timeStr?: string) => {
    const date = new Date(dateStr + (timeStr ? `T${timeStr}:00` : ""));
    return {
      date: date.toLocaleDateString("en-US", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      }),
      time: date.toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
      }),
    };
  };

  const handleJoinLesson = () => {
    if (lesson?.meetingUrl) {
      window.open(lesson.meetingUrl, "_blank");
    }
  };

  const handleCancelLesson = () => {
    // In real app, would show confirmation dialog and process cancellation
    console.log("Cancel lesson requested");
  };

  const handleRescheduleLesson = () => {
    // In real app, would navigate to rescheduling interface
    console.log("Reschedule lesson requested");
  };

  const handleLeaveFeedback = () => {
    // In real app, would open feedback modal or navigate to feedback page
    console.log("Leave feedback requested");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading lesson details...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="h-16 w-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Error Loading Lesson
          </h2>
          <p className="text-gray-600 mb-4">{error}</p>
          <div className="space-x-3">
            <button
              onClick={loadLessonData}
              className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
            >
              Try Again
            </button>
            <button
              onClick={() => navigate("/student-dashboard")}
              className="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600"
            >
              Return to Dashboard
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!lesson) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Lesson Not Found
          </h2>
          <p className="text-gray-600 mb-4">
            The lesson you're looking for doesn't exist or has been removed.
          </p>
          <button
            onClick={() => navigate("/student-dashboard")}
            className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
          >
            Return to Dashboard
          </button>
        </div>
      </div>
    );
  }

  const dateTime = formatDateTime(lesson.date, lesson.time);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <button
                onClick={() => navigate("/student-dashboard")}
                className="mr-4 p-2 rounded-md text-gray-400 hover:text-gray-600 hover:bg-gray-100"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">
                  {lesson.title}
                </h1>
                <p className="text-sm text-gray-500">
                  Booking #{lesson.bookingReference}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              {/* Moved buttons below to separate action group */}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Overview Section */}
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">
                Lesson Overview
              </h2>

              {/* Lesson Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div className="flex items-center">
                  <Calendar className="w-5 h-5 text-gray-400 mr-3" />
                  <div>
                    <p className="text-sm text-gray-500">Date</p>
                    <p className="font-medium">{dateTime.date}</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <Clock className="w-5 h-5 text-gray-400 mr-3" />
                  <div>
                    <p className="text-sm text-gray-500">Time</p>
                    <p className="font-medium">
                      {dateTime.time} ({lesson.duration} minutes)
                    </p>
                  </div>
                </div>
              </div>

              {/* Description */}
              <div className="mb-6">
                <h3 className="text-md font-medium text-gray-900 mb-2">
                  Description
                </h3>
                <p className="text-gray-600">{lesson.description}</p>
              </div>

              {/* Homework */}
              {lesson.homework && (
                <div className="mb-6">
                  <h3 className="text-md font-medium text-gray-900 mb-2">
                    Homework Assignment
                  </h3>
                  <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4">
                    <p className="text-gray-700 mb-2">
                      {lesson.homework.assigned}
                    </p>
                    {lesson.homework.dueDate && (
                      <p className="text-sm text-gray-500">
                        Due:{" "}
                        {new Date(lesson.homework.dueDate).toLocaleDateString()}
                      </p>
                    )}
                    <div className="mt-3">
                      <span
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          lesson.homework.completed
                            ? "bg-green-100 text-green-800"
                            : "bg-red-100 text-red-800"
                        }`}
                      >
                        {lesson.homework.completed ? "Completed" : "Pending"}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Notes */}
              {lesson.notes && (
                <div>
                  <h3 className="text-md font-medium text-gray-900 mb-2">
                    Lesson Notes
                  </h3>
                  <div className="bg-blue-50 border border-blue-200 rounded-md p-4">
                    <p className="text-gray-700">{lesson.notes}</p>
                  </div>
                </div>
              )}
            </div>

            {/* Lesson Journey Section */}
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">
                Lesson Journey
              </h2>
              <p className="text-gray-600 mb-6">
                Complete record of all activities from booking to completion
              </p>

              <div className="space-y-4">
                {records.map((record, index) => (
                  <div key={record.id} className="relative">
                    {/* Timeline line */}
                    {index < records.length - 1 && (
                      <div className="absolute left-5 top-8 bottom-0 w-0.5 bg-gray-200" />
                    )}

                    <div className="flex items-start">
                      <div className="flex-shrink-0 w-10 h-10 rounded-full border-2 border-white bg-gray-100 flex items-center justify-center shadow">
                        {getStatusIcon(record.status)}
                      </div>
                      <div className="ml-4 flex-1">
                        <div className="flex items-center justify-between">
                          <h4 className="text-sm font-medium text-gray-900">
                            {record.action}
                          </h4>
                          <span className="text-xs text-gray-500">
                            {new Date(record.timestamp).toLocaleDateString()}{" "}
                            {new Date(record.timestamp).toLocaleTimeString()}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">
                          {record.details}
                        </p>
                        {record.metadata && (
                          <div className="mt-2 text-xs text-gray-500">
                            {record.metadata.amount && (
                              <span className="mr-4">
                                Amount: ${record.metadata.amount}
                              </span>
                            )}
                            {record.metadata.duration && (
                              <span className="mr-4">
                                Duration: {record.metadata.duration} min
                              </span>
                            )}
                            {record.metadata.rating && (
                              <span>Rating: {record.metadata.rating}/5</span>
                            )}
                          </div>
                        )}
                        <div className="mt-1">
                          <span
                            className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                              record.actor === "student"
                                ? "bg-blue-100 text-blue-800"
                                : record.actor === "teacher"
                                  ? "bg-green-100 text-green-800"
                                  : "bg-gray-100 text-gray-800"
                            }`}
                          >
                            {record.actor}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Materials Section */}
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">
                Lesson Materials
              </h2>

              {lesson.materials.length > 0 ? (
                <div className="space-y-3">
                  {lesson.materials.map((material, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-3 bg-gray-50 rounded-md"
                    >
                      <div className="flex items-center">
                        <FileText className="w-5 h-5 text-gray-400 mr-3" />
                        <span className="text-sm font-medium text-gray-900">
                          {material}
                        </span>
                      </div>
                      <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                        Download
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500">No materials uploaded yet.</p>
              )}

              {lesson.recordingUrl && (
                <div className="mt-6">
                  <h3 className="text-md font-medium text-gray-900 mb-3">
                    Lesson Recording
                  </h3>
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-md">
                    <div className="flex items-center">
                      <Video className="w-5 h-5 text-blue-600 mr-3" />
                      <span className="text-sm font-medium text-gray-900">
                        Lesson Recording.mp4
                      </span>
                    </div>
                    <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                      Watch
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Column - Teacher Info & Quick Actions */}
          <div className="space-y-6">
            {/* Teacher Card */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Your Teacher
              </h3>
              <div className="flex items-center mb-4">
                <img
                  src={lesson.teacher.avatar}
                  alt={lesson.teacher.name}
                  className="w-12 h-12 rounded-full mr-4"
                />
                <div>
                  <h4 className="font-medium text-gray-900">
                    {lesson.teacher.name}
                  </h4>
                  <div className="flex items-center">
                    <Star className="w-4 h-4 text-yellow-400 mr-1" />
                    <span className="text-sm text-gray-600">
                      {lesson.teacher.rating} ({lesson.teacher.totalReviews}{" "}
                      reviews)
                    </span>
                  </div>
                </div>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">Language:</span>
                  <span className="font-medium">{lesson.teacher.language}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Rate:</span>
                  <span className="font-medium">
                    ${lesson.teacher.hourlyRate}/hour
                  </span>
                </div>
              </div>
              <button className="w-full mt-4 bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700">
                Message Teacher
              </button>
            </div>

            {/* Lesson Actions */}
            {lesson.status === "scheduled" && (
              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  Lesson Actions
                </h3>
                <div className="space-y-3">
                  <button
                    onClick={handleJoinLesson}
                    className="w-full bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 flex items-center justify-center"
                  >
                    <Video className="w-4 h-4 mr-2" />
                    Join Lesson
                  </button>
                  <button
                    onClick={handleRescheduleLesson}
                    className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700"
                  >
                    Reschedule
                  </button>
                  <button
                    onClick={handleCancelLesson}
                    className="w-full bg-red-600 text-white py-2 px-4 rounded-md hover:bg-red-700"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}

            {/* Leave Feedback */}
            {lesson.status === "completed" && !lesson.feedback?.student && (
              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  Rate Your Lesson
                </h3>
                <p className="text-gray-600 text-sm mb-4">
                  How was your lesson? Rate your teacher and leave a comment.
                </p>
                <button
                  onClick={handleLeaveFeedback}
                  className="w-full bg-yellow-500 text-white py-2 px-4 rounded-md hover:bg-yellow-600 flex items-center justify-center"
                >
                  <Star className="w-4 h-4 mr-2" />
                  Leave Feedback
                </button>
              </div>
            )}

            {/* Lesson Summary */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Lesson Summary
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-500">Status:</span>
                  <span
                    className={`font-medium capitalize ${
                      lesson.status === "scheduled"
                        ? "text-blue-600"
                        : lesson.status === "completed"
                          ? "text-green-600"
                          : lesson.status === "cancelled"
                            ? "text-red-600"
                            : "text-yellow-600"
                    }`}
                  >
                    {lesson.status}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Type:</span>
                  <span className="font-medium capitalize">{lesson.type}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Duration:</span>
                  <span className="font-medium">{lesson.duration} minutes</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Price:</span>
                  <span className="font-medium">
                    ${lesson.price} {lesson.currency}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Payment:</span>
                  <span
                    className={`font-medium capitalize ${
                      lesson.paymentStatus === "completed"
                        ? "text-green-600"
                        : lesson.paymentStatus === "pending"
                          ? "text-yellow-600"
                          : "text-red-600"
                    }`}
                  >
                    {lesson.paymentStatus}
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Quick Actions
              </h3>
              <div className="space-y-3">
                <button className="w-full text-left px-4 py-2 rounded-md bg-gray-50 hover:bg-gray-100 text-sm">
                  Book Another Lesson
                </button>
                <button className="w-full text-left px-4 py-2 rounded-md bg-gray-50 hover:bg-gray-100 text-sm">
                  View Teacher Profile
                </button>
                <button className="w-full text-left px-4 py-2 rounded-md bg-gray-50 hover:bg-gray-100 text-sm">
                  Download Receipt
                </button>
                <button className="w-full text-left px-4 py-2 rounded-md bg-gray-50 hover:bg-gray-100 text-sm">
                  Contact Support
                </button>
              </div>
            </div>

            {/* Cancellation Policy */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Cancellation Policy
              </h3>
              <p className="text-sm text-gray-600">
                {lesson.cancellationPolicy}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LessonDetails;
