import React, { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Globe,
  Mail,
  Lock,
  Eye,
  EyeOff,
  AlertCircle,
  CheckCircle,
} from "lucide-react";
import { db } from "@/lib/database";
import { useLanguage } from "@/contexts/LanguageContext";

export default function LoginFixed() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    try {
      // Use local demo authentication (we're in demo mode without backend)
      let user = null;

      // Check demo credentials
      if (email === "admin@talkcon.com" && password === "admin123") {
        user = {
          id: "admin_user",
          name: "Admin User",
          email: "admin@talkcon.com",
          type: "admin",
          role: "admin",
          avatar: "/placeholder.svg",
        };
      } else if (email === "demo@student.com" && password === "demo123") {
        // Ensure demo student exists
        db.createDemoStudent();
        const student = db.getUsers().find((u: any) => u.email === email) || {
          id: "demo_student",
          name: "Demo Student",
          email: "demo@student.com",
          type: "student",
          role: "student",
          avatar: "/placeholder.svg",
        };
        user = student;
      } else if (email === "demo@teacher.com" && password === "demo123") {
        // Ensure demo teacher exists
        db.createDemoTeacher();
        const teacher = db
          .getTeachers()
          .find((t: any) => t.email === email) || {
          id: "demo_teacher",
          name: "Demo Teacher",
          email: "demo@teacher.com",
          type: "teacher",
          role: "teacher",
          avatar: "/placeholder.svg",
          status: "approved",
        };
        user = teacher;
      } else {
        // Try to authenticate with database
        console.log("Attempting database authentication for:", email);
        console.log(
          "Available users in database:",
          db.getUsers().map((u) => ({ email: u.email, status: u.status })),
        );

        const authResult = db.authenticateUser(email, password);
        console.log("Authentication result:", authResult);

        if (authResult) {
          user = authResult.user;
        }
      }

      if (user) {
        // Store user data
        localStorage.setItem("talkcon_user", JSON.stringify(user));
        localStorage.setItem("auth_token", `demo_token_${Date.now()}`);

        // All users go to unified dashboard - they can switch views from there
        let redirectUrl = "/dashboard";

        // Only admin goes to admin dashboard
        if (user.type === "admin") {
          redirectUrl = "/admin";
        }

        const returnTo = location.state?.returnTo || redirectUrl;

        // Add a small delay to ensure state is updated
        setTimeout(() => {
          navigate(returnTo, { replace: true });
        }, 100);
      } else {
        setError("Invalid email or password. Please try again.");
      }
    } catch (error: any) {
      console.error("Login error:", error);
      setError(error.message || "Login failed. Please check your credentials.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSocialLogin = async (
    provider: "google" | "facebook" | "apple",
  ) => {
    setError("");
    setIsLoading(true);

    try {
      // Use mock social login for demo (no backend available)
      setTimeout(() => {
        const demoUser = {
          id: `${provider}_user_${Date.now()}`,
          name: `${provider.charAt(0).toUpperCase() + provider.slice(1)} User`,
          email: `demo@${provider}.com`,
          type: "student",
          role: "student",
          avatar: "/placeholder.svg",
          provider: provider,
        };

        localStorage.setItem("talkcon_user", JSON.stringify(demoUser));
        localStorage.setItem("auth_token", `${provider}_token_${Date.now()}`);

        setIsLoading(false);
        navigate("/dashboard", { replace: true });
      }, 1500);
    } catch (error: any) {
      console.error("Social login error:", error);
      setError("Social login failed. Please try again.");
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5 flex items-center justify-center p-4">
      {/* Background Pattern */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center space-x-2">
            <div className="flex items-center space-x-3">
              <div className="relative h-10 w-10 rounded-xl bg-gradient-to-br from-red-600 via-red-700 to-red-900 shadow-lg transform rotate-3">
                <div className="absolute inset-0.5 rounded-lg bg-gradient-to-br from-red-500/90 to-red-800/90">
                  <div className="absolute top-1 left-1 w-3 h-2.5 bg-white/90 rounded-sm"></div>
                  <div className="absolute top-2.5 right-1 w-2.5 h-2 bg-white/70 rounded-sm"></div>
                  <div className="absolute bottom-1.5 left-1.5 w-2 h-1.5 bg-white/50 rounded-sm"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-white font-bold text-sm leading-none">
                      T
                    </div>
                  </div>
                </div>
                <div className="absolute -top-1 -right-1 w-2 h-2 bg-yellow-400 rounded-full shadow-sm"></div>
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-red-800 to-red-900 bg-clip-text text-transparent">
                Talkcon
              </span>
            </div>
          </Link>
        </div>

        <Card className="shadow-xl border-0 bg-background/80 backdrop-blur-sm">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl text-center">
              {t("auth.login.title") || "Welcome back"}
            </CardTitle>
            <p className="text-center text-sm text-muted-foreground">
              {t("auth.login.subtitle") || "Login to your account to continue"}
            </p>
          </CardHeader>
          <CardContent>
            {error && (
              <Alert variant="destructive" className="mb-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {/* Social Login Buttons */}
            <div className="space-y-3 mb-6">
              <Button
                variant="outline"
                className="w-full h-11 text-sm font-medium"
                onClick={() => handleSocialLogin("google")}
                disabled={isLoading}
              >
                <svg className="w-5 h-5 mr-3" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  />
                </svg>
                Continue with Google
              </Button>

              <div className="grid grid-cols-2 gap-3">
                <Button
                  variant="outline"
                  className="h-11 text-sm font-medium"
                  onClick={() => handleSocialLogin("facebook")}
                  disabled={isLoading}
                >
                  <svg
                    className="w-5 h-5 mr-2"
                    fill="#1877F2"
                    viewBox="0 0 24 24"
                  >
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                  </svg>
                  Facebook
                </Button>

                <Button
                  variant="outline"
                  className="h-11 text-sm font-medium"
                  onClick={() => handleSocialLogin("apple")}
                  disabled={isLoading}
                >
                  <svg
                    className="w-5 h-5 mr-2"
                    fill="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z" />
                  </svg>
                  Apple
                </Button>
              </div>
            </div>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <Separator className="w-full" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">
                  Or continue with email
                </span>
              </div>
            </div>

            {/* Demo Credentials */}
            <div className="bg-blue-50 border border-blue-200 rounded-md p-3 mt-4">
              <h4 className="text-sm font-medium text-blue-900 mb-2">
                Demo Accounts
              </h4>
              <div className="text-xs text-blue-700 space-y-1">
                <div>
                  <strong>Student:</strong> demo@student.com / demo123
                </div>
                <div>
                  <strong>Teacher:</strong> demo@teacher.com / demo123
                </div>
                <div>
                  <strong>Admin:</strong> admin@talkcon.com / admin123
                </div>
              </div>
            </div>

            <form onSubmit={handleLogin} className="space-y-4 mt-6">
              <div className="space-y-2">
                <Label htmlFor="email">{t("auth.email") || "Email"}</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10"
                    required
                    disabled={isLoading}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">
                  {t("auth.password") || "Password"}
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 pr-10"
                    required
                    disabled={isLoading}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4 text-muted-foreground" />
                    ) : (
                      <Eye className="h-4 w-4 text-muted-foreground" />
                    )}
                  </Button>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="remember"
                    checked={rememberMe}
                    onCheckedChange={(checked) => setRememberMe(!!checked)}
                  />
                  <Label htmlFor="remember" className="text-sm cursor-pointer">
                    Remember me
                  </Label>
                </div>
                <Link
                  to="/forgot-password"
                  className="text-sm text-primary hover:underline"
                >
                  Forgot password?
                </Link>
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={isLoading}
                size="lg"
              >
                {isLoading ? "Logging in..." : "Login"}
              </Button>
            </form>

            <div className="mt-6">
              <div className="text-center text-sm">
                <span className="text-muted-foreground">
                  Don't have an account?{" "}
                </span>
                <Link
                  to="/signup"
                  className="text-primary hover:underline font-medium"
                >
                  Sign up
                </Link>
              </div>
            </div>

            {/* Demo credentials */}
            <div className="mt-6 p-4 bg-muted/50 rounded-lg">
              <h4 className="text-sm font-medium mb-2">Demo Accounts:</h4>
              <div className="text-xs space-y-1 text-muted-foreground">
                <div>Student: demo@student.com / demo123</div>
                <div>Teacher: demo@teacher.com / demo123</div>
                <div>Admin: admin@talkcon.com / admin123</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
