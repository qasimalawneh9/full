import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Navbar } from "@/components/ui/navbar";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Calendar,
  Clock,
  BookOpen,
  TrendingUp,
  Star,
  MessageCircle,
  Video,
  Award,
  Wallet,
  Plus,
  CreditCard,
  ArrowUpRight,
  DollarSign,
  GraduationCap,
  Users,
  Target,
  Activity,
  FileText,
  CheckCircle,
  AlertCircle,
  Bell,
  Heart,
  Play,
  Globe,
  Zap,
  BarChart3,
  TrendingDown,
  Eye,
  Edit,
  Flame,
  Trophy,
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";
import {
  studentDashboardSimpleService as studentDashboardService,
  StudentDashboardData,
  UpcomingLesson,
  Achievement,
  LearningGoal,
} from "@/api/services/student-dashboard-simple.service";

export default function StudentDashboardEnhanced() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [dashboardData, setDashboardData] =
    useState<StudentDashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedTab, setSelectedTab] = useState("overview");

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }

    if (user.type !== "student") {
      navigate("/dashboard");
      return;
    }

    loadDashboardData();
  }, [user, navigate]);

  const loadDashboardData = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await studentDashboardService.getDashboardData();
      if (response.success && response.data) {
        setDashboardData(response.data);
      } else {
        throw new Error(response.message || "Failed to load dashboard data");
      }
    } catch (err) {
      console.error("Failed to load dashboard data:", err);
      setError("Failed to load dashboard data. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleTopUpWallet = () => {
    // For demo purposes
    toast({
      title: "Wallet Top-up",
      description:
        "This would open the payment dialog in a real implementation.",
    });
  };

  const handleBookLesson = (teacher?: any) => {
    navigate("/teachers");
  };

  const handleViewLesson = (lesson: UpcomingLesson) => {
    navigate(`/lesson-details/${lesson.id}`);
  };

  if (!user || user.type !== "student") {
    return null;
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar isLoggedIn={true} userType="student" />
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">Loading your dashboard...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar isLoggedIn={true} userType="student" />
        <div className="container mx-auto px-4 py-8">
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
          <Button onClick={loadDashboardData} className="mt-4">
            Try Again
          </Button>
        </div>
      </div>
    );
  }

  const data = dashboardData!;

  return (
    <div className="min-h-screen bg-background">
      <Navbar isLoggedIn={true} userType="student" />

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">
              Welcome back, {data.student.name || user.name}! 👋
            </h1>
            <p className="text-muted-foreground">
              Continue your language learning journey
            </p>
          </div>
          <div className="flex space-x-3">
            <Button
              onClick={handleBookLesson}
              className="flex items-center space-x-2"
            >
              <Plus className="h-4 w-4" />
              <span>Book Lesson</span>
            </Button>
            <Button variant="outline" onClick={() => navigate("/teachers")}>
              <Users className="h-4 w-4 mr-2" />
              Find Teachers
            </Button>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Lessons</p>
                  <p className="text-2xl font-bold">
                    {data.stats.totalLessons}
                  </p>
                </div>
                <BookOpen className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Hours Learned</p>
                  <p className="text-2xl font-bold">
                    {Math.round(data.stats.totalHours)}
                  </p>
                </div>
                <Clock className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">
                    Current Streak
                  </p>
                  <p className="text-2xl font-bold flex items-center">
                    {data.stats.currentStreak}
                    <Flame className="h-5 w-5 text-orange-500 ml-1" />
                  </p>
                </div>
                <Trophy className="h-8 w-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">
                    Wallet Balance
                  </p>
                  <p className="text-2xl font-bold">${data.wallet.balance}</p>
                </div>
                <Wallet className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs
          value={selectedTab}
          onValueChange={setSelectedTab}
          className="space-y-6"
        >
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="progress">Progress</TabsTrigger>
            <TabsTrigger value="lessons">Lessons</TabsTrigger>
            <TabsTrigger value="teachers">Teachers</TabsTrigger>
            <TabsTrigger value="goals">Goals</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Upcoming Lessons */}
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Calendar className="h-5 w-5" />
                      <span>Upcoming Lessons</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {data.upcomingLessons.length === 0 ? (
                      <div className="text-center py-8">
                        <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                        <p className="text-muted-foreground mb-4">
                          No upcoming lessons
                        </p>
                        <Button onClick={handleBookLesson}>
                          Book Your First Lesson
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {data.upcomingLessons.slice(0, 3).map((lesson) => (
                          <div
                            key={lesson.id}
                            className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                            onClick={() =>
                              navigate(`/lesson-details/${lesson.id}`)
                            }
                          >
                            <div className="flex items-center space-x-3">
                              <Avatar>
                                <AvatarImage src={lesson.teacherAvatar} />
                                <AvatarFallback>
                                  {lesson.teacherName[0]}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="font-medium">{lesson.subject}</p>
                                <p className="text-sm text-muted-foreground">
                                  with {lesson.teacherName}
                                </p>
                                <p className="text-sm text-muted-foreground">
                                  {lesson.date} at {lesson.time}
                                </p>
                              </div>
                            </div>
                            <div className="flex space-x-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  navigate(`/lesson-details/${lesson.id}`);
                                }}
                              >
                                <Eye className="h-4 w-4 mr-2" />
                                Details
                              </Button>
                              <Button size="sm" variant="outline">
                                <MessageCircle className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleViewLesson(lesson);
                                }}
                              >
                                <Video className="h-4 w-4 mr-2" />
                                Join
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Recent Activity */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Activity className="h-5 w-5" />
                    <span>Recent Activity</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {data.recentActivity.slice(0, 5).map((activity) => (
                      <div
                        key={activity.id}
                        className="flex items-start space-x-3"
                      >
                        <div className="text-lg">{activity.icon}</div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium">
                            {activity.title}
                          </p>
                          <p className="text-xs text-muted-foreground truncate">
                            {activity.description}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(activity.date).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Achievements */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Award className="h-5 w-5" />
                  <span>Recent Achievements</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {data.achievements.slice(0, 3).map((achievement) => (
                    <div
                      key={achievement.id}
                      className="flex items-center space-x-3 p-4 border rounded-lg"
                    >
                      <div className="text-2xl">{achievement.icon}</div>
                      <div>
                        <p className="font-medium">{achievement.title}</p>
                        <p className="text-sm text-muted-foreground">
                          {achievement.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Progress Tab */}
          <TabsContent value="progress" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {data.progress.map((lang) => (
                <Card key={lang.language}>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>{lang.language}</span>
                      <Badge variant="secondary">{lang.level}</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Overall Progress</span>
                        <span>{lang.progress}%</span>
                      </div>
                      <Progress value={lang.progress} />
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <div className="flex justify-between">
                          <span>Vocabulary</span>
                          <span>{lang.vocabulary}%</span>
                        </div>
                        <Progress value={lang.vocabulary} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between">
                          <span>Grammar</span>
                          <span>{lang.grammar}%</span>
                        </div>
                        <Progress value={lang.grammar} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between">
                          <span>Speaking</span>
                          <span>{lang.speaking}%</span>
                        </div>
                        <Progress value={lang.speaking} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between">
                          <span>Listening</span>
                          <span>{lang.listening}%</span>
                        </div>
                        <Progress value={lang.listening} className="h-2" />
                      </div>
                    </div>

                    <div className="pt-2 border-t">
                      <p className="text-sm text-muted-foreground">
                        Next milestone: {lang.nextMilestone}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Lessons completed: {lang.lessonsCompleted}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Lessons Tab */}
          <TabsContent value="lessons" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Upcoming */}
              <Card>
                <CardHeader>
                  <CardTitle>Upcoming Lessons</CardTitle>
                </CardHeader>
                <CardContent>
                  {data.upcomingLessons.length === 0 ? (
                    <div className="text-center py-8">
                      <p className="text-muted-foreground mb-4">
                        No upcoming lessons
                      </p>
                      <Button onClick={handleBookLesson}>Book a Lesson</Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {data.upcomingLessons.map((lesson) => (
                        <div
                          key={lesson.id}
                          className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                          onClick={() =>
                            navigate(`/lesson-details/${lesson.id}`)
                          }
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">{lesson.subject}</p>
                              <p className="text-sm text-muted-foreground">
                                with {lesson.teacherName}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                {lesson.date} at {lesson.time} (
                                {lesson.duration}min)
                              </p>
                            </div>
                            <div className="flex space-x-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  navigate(`/lesson-details/${lesson.id}`);
                                }}
                              >
                                <Eye className="h-4 w-4 mr-2" />
                                Details
                              </Button>
                              <Button
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleViewLesson(lesson);
                                }}
                              >
                                Join
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Wallet */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Wallet</span>
                    <Button size="sm" onClick={handleTopUpWallet}>
                      <Plus className="h-4 w-4 mr-2" />
                      Top Up
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center mb-6">
                    <p className="text-3xl font-bold">${data.wallet.balance}</p>
                    <p className="text-muted-foreground">Current Balance</p>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-medium">Recent Transactions</h4>
                    {data.wallet.transactions.slice(0, 3).map((tx) => (
                      <div
                        key={tx.id}
                        className="flex items-center justify-between"
                      >
                        <div>
                          <p className="text-sm font-medium">
                            {tx.description}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(tx.date).toLocaleDateString()}
                          </p>
                        </div>
                        <div
                          className={`text-sm font-medium ${
                            tx.amount > 0 ? "text-green-600" : "text-red-600"
                          }`}
                        >
                          {tx.amount > 0 ? "+" : ""}${Math.abs(tx.amount)}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Teachers Tab */}
          <TabsContent value="teachers" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Favorite Teachers</span>
                  <Button size="sm" onClick={() => navigate("/teachers")}>
                    <Plus className="h-4 w-4 mr-2" />
                    Find More
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {data.favoriteTeachers.length === 0 ? (
                  <div className="text-center py-8">
                    <Heart className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground mb-4">
                      No favorite teachers yet
                    </p>
                    <Button onClick={() => navigate("/teachers")}>
                      Browse Teachers
                    </Button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {data.favoriteTeachers.map((teacher) => (
                      <div
                        key={teacher.id}
                        className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                        onClick={() => navigate(`/teachers/${teacher.id}`)}
                      >
                        <div className="flex items-center space-x-3 mb-3">
                          <Avatar>
                            <AvatarImage src={teacher.avatar} />
                            <AvatarFallback>{teacher.name[0]}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <p className="font-medium">{teacher.name}</p>
                            <div className="flex items-center space-x-1">
                              <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                              <span className="text-sm">{teacher.rating}</span>
                              <span className="text-sm text-muted-foreground">
                                ({teacher.reviewCount})
                              </span>
                            </div>
                          </div>
                          {teacher.isOnline && (
                            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          )}
                        </div>

                        <div className="flex flex-wrap gap-1 mb-3">
                          {teacher.languages.slice(0, 2).map((lang) => (
                            <Badge
                              key={lang}
                              variant="secondary"
                              className="text-xs"
                            >
                              {lang}
                            </Badge>
                          ))}
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="font-medium">
                            ${teacher.price}/hr
                          </span>
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={(e) => {
                                e.stopPropagation();
                                navigate("/messaging");
                              }}
                            >
                              <MessageCircle className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation();
                                navigate(`/teachers/${teacher.id}`);
                              }}
                            >
                              Book
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Goals Tab */}
          <TabsContent value="goals" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {data.goals.map((goal) => (
                <Card key={goal.id}>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>{goal.title}</span>
                      {goal.completed ? (
                        <CheckCircle className="h-5 w-5 text-green-600" />
                      ) : (
                        <Target className="h-5 w-5 text-blue-600" />
                      )}
                    </CardTitle>
                    <p className="text-sm text-muted-foreground">
                      {goal.description}
                    </p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Progress</span>
                        <span>{goal.progress}%</span>
                      </div>
                      <Progress value={goal.progress} />
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-2">Milestones</p>
                      <div className="space-y-2">
                        {goal.milestones.map((milestone) => (
                          <div
                            key={milestone.id}
                            className="flex items-center space-x-2"
                          >
                            {milestone.completed ? (
                              <CheckCircle className="h-4 w-4 text-green-600" />
                            ) : (
                              <div className="h-4 w-4 border rounded-full" />
                            )}
                            <span
                              className={`text-sm ${
                                milestone.completed
                                  ? "line-through text-muted-foreground"
                                  : ""
                              }`}
                            >
                              {milestone.title}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="pt-2 border-t text-sm text-muted-foreground">
                      Target: {new Date(goal.targetDate).toLocaleDateString()}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
