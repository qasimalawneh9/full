import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Navbar } from "@/components/ui/navbar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/components/ui/use-toast";
import {
  Upload,
  Video,
  Award,
  BookOpen,
  Globe,
  Clock,
  CheckCircle,
  AlertCircle,
  Star,
  Users,
} from "lucide-react";

const languages = [
  "English",
  "Spanish",
  "French",
  "German",
  "Italian",
  "Portuguese",
  "Chinese",
  "Japanese",
  "Korean",
  "Arabic",
  "Russian",
  "Dutch",
  "Hindi",
  "Urdu",
  "Turkish",
  "Greek",
  "Thai",
  "Vietnamese",
  "Polish",
  "Romanian",
];

const experienceLevels = [
  "Less than 1 year",
  "1-2 years",
  "3-5 years",
  "6-10 years",
  "10+ years",
];

const educationLevels = [
  "High School",
  "Some College",
  "Bachelor's Degree",
  "Master's Degree",
  "PhD",
  "Other",
];

export default function TeacherApplication() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();

  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [progressRestored, setProgressRestored] = useState(false);

  const [formData, setFormData] = useState({
    // Personal Information
    firstName: "",
    lastName: "",
    email: user?.email || "",
    phone: "",
    country: "",
    city: "",
    timezone: "",
    dateOfBirth: "",

    // Language & Teaching Information
    nativeLanguage: "",
    teachingLanguages: [] as string[],
    proficiencyLevels: {} as Record<string, string>,
    experience: "",
    education: "",
    certifications: [] as string[],

    // Teaching Preferences
    availability: {
      monday: { available: false, startTime: "", endTime: "" },
      tuesday: { available: false, startTime: "", endTime: "" },
      wednesday: { available: false, startTime: "", endTime: "" },
      thursday: { available: false, startTime: "", endTime: "" },
      friday: { available: false, startTime: "", endTime: "" },
      saturday: { available: false, startTime: "", endTime: "" },
      sunday: { available: false, startTime: "", endTime: "" },
    },
    hourlyRate: 15,
    specialties: [] as string[],
    ageGroups: [] as string[],

    // Profile & Media
    bio: "",
    teachingStyle: "",
    motivation: "",
    videoIntroduction: "",
    profileImage: "",

    // Verification
    acceptTerms: false,
    backgroundCheck: false,
    marketingEmails: false,
  });

  // Progress saving keys
  const APPLICATION_PROGRESS_KEY = "talkcon_teacher_application_progress";

  // Load saved progress on component mount
  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }

    const savedProgress = localStorage.getItem(APPLICATION_PROGRESS_KEY);
    if (savedProgress) {
      try {
        const {
          step: savedStep,
          formData: savedFormData,
          timestamp,
        } = JSON.parse(savedProgress);
        // Only restore if saved within last 7 days
        const isRecent =
          timestamp && Date.now() - timestamp < 7 * 24 * 60 * 60 * 1000;
        if (
          isRecent &&
          (savedStep > 1 ||
            Object.keys(savedFormData || {}).some((key) => savedFormData[key]))
        ) {
          setStep(savedStep || 1);
          setFormData((prev) => ({
            ...prev,
            ...savedFormData,
            email: user.email,
          }));
          setProgressRestored(true);
        }
      } catch (error) {
        console.error("Failed to load application progress:", error);
      }
    }
  }, [user, navigate]);

  // Save progress whenever form data or step changes
  useEffect(() => {
    if (user) {
      const progressData = {
        step,
        formData: { ...formData, email: user.email },
        timestamp: Date.now(),
      };
      localStorage.setItem(
        APPLICATION_PROGRESS_KEY,
        JSON.stringify(progressData),
      );
    }
  }, [step, formData, user]);

  // Clear progress after successful submission
  const clearProgress = () => {
    localStorage.removeItem(APPLICATION_PROGRESS_KEY);
  };

  const handleInputChange = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleLanguageToggle = (language: string) => {
    const currentLanguages = formData.teachingLanguages;
    const updatedLanguages = currentLanguages.includes(language)
      ? currentLanguages.filter((l) => l !== language)
      : [...currentLanguages, language];

    handleInputChange("teachingLanguages", updatedLanguages);
  };

  const handleSpecialtyToggle = (specialty: string) => {
    const currentSpecialties = formData.specialties;
    const updatedSpecialties = currentSpecialties.includes(specialty)
      ? currentSpecialties.filter((s) => s !== specialty)
      : [...currentSpecialties, specialty];

    handleInputChange("specialties", updatedSpecialties);
  };

  const validateStep1 = () => {
    if (!formData.firstName || !formData.lastName || !formData.country) {
      setError("Please fill in all required fields in Step 1");
      return false;
    }
    return true;
  };

  const validateStep2 = () => {
    if (
      !formData.nativeLanguage ||
      formData.teachingLanguages.length === 0 ||
      !formData.experience
    ) {
      setError("Please complete all required fields in Step 2");
      return false;
    }
    return true;
  };

  const validateStep3 = () => {
    if (!formData.bio || formData.bio.length < 100) {
      setError("Please write a bio of at least 100 characters");
      return false;
    }
    if (!formData.profileImage) {
      setError("Please upload a profile photo");
      return false;
    }
    if (!formData.videoIntroduction) {
      setError("Please upload an introduction video");
      return false;
    }
    return true;
  };

  const validateStep4 = () => {
    console.log(
      "TeacherApplication: Validating step 4, acceptTerms:",
      formData.acceptTerms,
    );
    if (!formData.acceptTerms) {
      setError("Please accept the terms and conditions");
      return false;
    }
    return true;
  };

  const handleNext = async () => {
    setError("");
    let isValid = false;

    switch (step) {
      case 1:
        isValid = validateStep1();
        break;
      case 2:
        isValid = validateStep2();
        break;
      case 3:
        isValid = validateStep3();
        break;
      case 4:
        isValid = validateStep4();
        break;
    }

    if (isValid) {
      if (step < 4) {
        setStep(step + 1);
      } else {
        console.log("TeacherApplication: Submitting application on step 4");
        handleSubmit();
      }
    } else {
      console.log("TeacherApplication: Validation failed for step", step);
    }
  };

  const handleSubmit = async () => {
    console.log("TeacherApplication: handleSubmit called");
    console.log("TeacherApplication: Current step:", step);
    console.log("TeacherApplication: Form data:", formData);
    console.log("TeacherApplication: User:", user);

    setLoading(true);
    try {
      if (!user) {
        throw new Error("User not logged in");
      }

      // Prepare application data for API
      const applicationData = {
        firstName: formData.firstName,
        lastName: formData.lastName,
        nativeLanguage: formData.nativeLanguage,
        teachingLanguages: formData.teachingLanguages,
        experience: formData.experience,
        education: formData.education,
        certifications: formData.certifications,
        availability: formData.availability,
        hourlyRate: formData.hourlyRate,
        bio: formData.bio,
        videoIntroduction: formData.videoIntroduction,
      };

      // Since we're in demo mode without a backend, skip API and use local storage
      console.log("Demo mode: Simulating teacher application submission");

      // Store application in localStorage for demo purposes
      const applicationWithId = {
        ...applicationData,
        id: `app_${Date.now()}`,
        userId: user.id,
        status: "pending",
        submittedAt: new Date().toISOString(),
      };

      const existingApplications = JSON.parse(
        localStorage.getItem("teacher_applications") || "[]",
      );
      existingApplications.push(applicationWithId);
      localStorage.setItem(
        "teacher_applications",
        JSON.stringify(existingApplications),
      );

      clearProgress();
      toast({
        title: "Application Submitted Successfully!",
        description:
          "Your teacher application has been submitted for review. You'll receive an email once it's approved.",
      });

      console.log("TeacherApplication: Navigating to review page...");
      console.log(
        "TeacherApplication: Stored application data:",
        applicationWithId,
      );
      navigate("/teacher-application-under-review");
    } catch (error: any) {
      console.error("Application submission failed:", error);
      const errorMessage =
        error.response?.data?.message ||
        error.message ||
        "Failed to submit application";
      setError(errorMessage);
      toast({
        title: "Application Failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const renderStep1 = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold mb-2">Personal Information</h2>
        <p className="text-muted-foreground">Tell us about yourself</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="firstName">First Name *</Label>
          <Input
            id="firstName"
            placeholder="John"
            value={formData.firstName}
            onChange={(e) => handleInputChange("firstName", e.target.value)}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="lastName">Last Name *</Label>
          <Input
            id="lastName"
            placeholder="Doe"
            value={formData.lastName}
            onChange={(e) => handleInputChange("lastName", e.target.value)}
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            type="email"
            value={formData.email}
            disabled
            className="bg-muted"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="phone">Phone Number</Label>
          <Input
            id="phone"
            placeholder="+1 (555) 123-4567"
            value={formData.phone}
            onChange={(e) => handleInputChange("phone", e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="country">Country *</Label>
          <Select
            value={formData.country}
            onValueChange={(value) => handleInputChange("country", value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select your country" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="us">United States</SelectItem>
              <SelectItem value="uk">United Kingdom</SelectItem>
              <SelectItem value="ca">Canada</SelectItem>
              <SelectItem value="au">Australia</SelectItem>
              <SelectItem value="de">Germany</SelectItem>
              <SelectItem value="fr">France</SelectItem>
              <SelectItem value="es">Spain</SelectItem>
              <SelectItem value="it">Italy</SelectItem>
              <SelectItem value="mx">Mexico</SelectItem>
              <SelectItem value="br">Brazil</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="city">City</Label>
          <Input
            id="city"
            placeholder="New York"
            value={formData.city}
            onChange={(e) => handleInputChange("city", e.target.value)}
          />
        </div>
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold mb-2">Language & Teaching</h2>
        <p className="text-muted-foreground">
          Tell us about your teaching experience
        </p>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label>What's your native language? *</Label>
          <Select
            value={formData.nativeLanguage}
            onValueChange={(value) =>
              handleInputChange("nativeLanguage", value)
            }
          >
            <SelectTrigger>
              <SelectValue placeholder="Select your native language" />
            </SelectTrigger>
            <SelectContent>
              {languages.map((language) => (
                <SelectItem key={language} value={language}>
                  {language}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-3">
          <Label>Which languages can you teach? *</Label>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {languages.map((language) => (
              <Button
                key={language}
                type="button"
                variant={
                  formData.teachingLanguages.includes(language)
                    ? "default"
                    : "outline"
                }
                size="sm"
                onClick={() => handleLanguageToggle(language)}
                className="justify-start"
              >
                {language}
              </Button>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <Label>Teaching Experience *</Label>
          <Select
            value={formData.experience}
            onValueChange={(value) => handleInputChange("experience", value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select your experience level" />
            </SelectTrigger>
            <SelectContent>
              {experienceLevels.map((level) => (
                <SelectItem key={level} value={level}>
                  {level}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Education Level</Label>
          <Select
            value={formData.education}
            onValueChange={(value) => handleInputChange("education", value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select your education level" />
            </SelectTrigger>
            <SelectContent>
              {educationLevels.map((level) => (
                <SelectItem key={level} value={level}>
                  {level}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Hourly Rate (USD)</Label>
          <div className="flex items-center space-x-2">
            <span className="text-lg font-medium">$</span>
            <Input
              type="number"
              min="5"
              max="200"
              value={formData.hourlyRate}
              onChange={(e) =>
                handleInputChange("hourlyRate", parseInt(e.target.value) || 15)
              }
              className="w-24"
            />
            <span className="text-muted-foreground">/hour</span>
          </div>
        </div>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold mb-2">Profile & Teaching Style</h2>
        <p className="text-muted-foreground">Help students get to know you</p>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="bio">About You *</Label>
          <Textarea
            id="bio"
            placeholder="Tell students about yourself, your teaching style, and why you love teaching languages..."
            value={formData.bio}
            onChange={(e) => handleInputChange("bio", e.target.value)}
            rows={6}
            className="resize-none"
          />
          <p className="text-sm text-muted-foreground">
            {formData.bio.length}/100 characters minimum
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="teachingStyle">Teaching Style</Label>
          <Textarea
            id="teachingStyle"
            placeholder="Describe your teaching methodology and approach..."
            value={formData.teachingStyle}
            onChange={(e) => handleInputChange("teachingStyle", e.target.value)}
            rows={4}
            className="resize-none"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="motivation">Why do you want to teach?</Label>
          <Textarea
            id="motivation"
            placeholder="Share your motivation for teaching languages..."
            value={formData.motivation}
            onChange={(e) => handleInputChange("motivation", e.target.value)}
            rows={4}
            className="resize-none"
          />
        </div>

        {/* Profile Photo Upload */}
        <div className="space-y-2">
          <Label htmlFor="profileImage">Profile Photo *</Label>
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
            {formData.profileImage ? (
              <div className="space-y-4">
                <img
                  src={formData.profileImage}
                  alt="Profile preview"
                  className="w-24 h-24 rounded-full mx-auto object-cover"
                />
                <div>
                  <p className="text-sm text-green-600 mb-2">
                    ✓ Photo uploaded
                  </p>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleInputChange("profileImage", "")}
                  >
                    Remove Photo
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <Upload className="w-12 h-12 text-gray-400 mx-auto" />
                <div>
                  <p className="text-sm font-medium">
                    Upload your profile photo
                  </p>
                  <p className="text-xs text-muted-foreground">
                    JPG, PNG up to 5MB. Recommended: 400x400px
                  </p>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    // Simulate photo upload for demo
                    const demoPhoto = "/placeholder.svg";
                    handleInputChange("profileImage", demoPhoto);
                  }}
                >
                  Choose Photo
                </Button>
              </div>
            )}
          </div>
          <p className="text-xs text-muted-foreground">
            A professional photo helps students connect with you
          </p>
        </div>

        {/* Video Introduction Upload */}
        <div className="space-y-2">
          <Label htmlFor="videoIntroduction">Introduction Video *</Label>
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
            {formData.videoIntroduction ? (
              <div className="space-y-4">
                <div className="w-full max-w-sm mx-auto bg-gray-100 rounded-lg p-4">
                  <Video className="w-16 h-16 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm font-medium">introduction_video.mp4</p>
                  <p className="text-xs text-muted-foreground">2:30 duration</p>
                </div>
                <div>
                  <p className="text-sm text-green-600 mb-2">
                    ✓ Video uploaded
                  </p>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleInputChange("videoIntroduction", "")}
                  >
                    Remove Video
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <Video className="w-12 h-12 text-gray-400 mx-auto" />
                <div>
                  <p className="text-sm font-medium">
                    Upload your introduction video
                  </p>
                  <p className="text-xs text-muted-foreground">
                    MP4, MOV up to 100MB. Recommended: 1-3 minutes
                  </p>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    // Simulate video upload for demo
                    const demoVideo = "demo_introduction_video.mp4";
                    handleInputChange("videoIntroduction", demoVideo);
                  }}
                >
                  Record/Upload Video
                </Button>
              </div>
            )}
          </div>
          <p className="text-xs text-muted-foreground">
            Introduce yourself and your teaching style (1-3 minutes)
          </p>
        </div>
      </div>
    </div>
  );

  const renderStep4 = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold mb-2">Review & Submit</h2>
        <p className="text-muted-foreground">
          Please review your information and agree to our terms
        </p>
      </div>

      <div className="space-y-4">
        {/* Application Summary */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Application Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <strong>Name:</strong> {formData.firstName} {formData.lastName}
              </div>
              <div>
                <strong>Country:</strong> {formData.country}
              </div>
              <div>
                <strong>Native Language:</strong> {formData.nativeLanguage}
              </div>
              <div>
                <strong>Teaching Experience:</strong> {formData.experience}
              </div>
              <div className="col-span-2">
                <strong>Teaching Languages:</strong>{" "}
                {formData.teachingLanguages.join(", ")}
              </div>
              <div>
                <strong>Hourly Rate:</strong> ${formData.hourlyRate}/hour
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Terms and Agreements */}
        <div className="space-y-4 p-4 bg-muted/50 rounded-lg">
          <div className="flex items-start space-x-2">
            <Checkbox
              id="terms"
              checked={formData.acceptTerms}
              onCheckedChange={(checked) =>
                handleInputChange("acceptTerms", !!checked)
              }
            />
            <Label
              htmlFor="terms"
              className="text-sm cursor-pointer leading-relaxed"
            >
              I agree to the{" "}
              <a
                href="/terms"
                target="_blank"
                className="text-primary hover:underline"
              >
                Terms of Service
              </a>{" "}
              and{" "}
              <a
                href="/legal/tutor-agreement"
                target="_blank"
                className="text-primary hover:underline"
              >
                Tutor Agreement
              </a>
              . I understand that my application will be reviewed and I'll be
              notified of the decision.
            </Label>
          </div>
        </div>
      </div>
    </div>
  );

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-2">Teacher Application</h1>
            <p className="text-muted-foreground">
              Join thousands of teachers earning money by sharing their language
              expertise
            </p>
          </div>

          {/* Progress Indicator */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              {[1, 2, 3, 4].map((stepNum) => (
                <div
                  key={stepNum}
                  className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                    step >= stepNum
                      ? "bg-primary border-primary text-primary-foreground"
                      : "border-muted-foreground text-muted-foreground"
                  }`}
                >
                  {step > stepNum ? (
                    <CheckCircle className="w-5 h-5" />
                  ) : (
                    stepNum
                  )}
                </div>
              ))}
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div
                className="bg-primary h-2 rounded-full transition-all"
                style={{ width: `${((step - 1) / 3) * 100}%` }}
              />
            </div>
          </div>

          <Card className="shadow-lg">
            <CardContent className="p-8">
              {progressRestored && (
                <Alert className="mb-6 bg-green-50 border-green-200">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-800">
                    <div className="flex items-center justify-between">
                      <span>
                        <strong>Welcome back!</strong> We've restored your
                        application progress.
                      </span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          clearProgress();
                          setProgressRestored(false);
                          setStep(1);
                          setFormData({
                            firstName: "",
                            lastName: "",
                            email: user?.email || "",
                            phone: "",
                            country: "",
                            city: "",
                            timezone: "",
                            dateOfBirth: "",
                            nativeLanguage: "",
                            teachingLanguages: [],
                            proficiencyLevels: {},
                            experience: "",
                            education: "",
                            certifications: [],
                            availability: {
                              monday: {
                                available: false,
                                startTime: "",
                                endTime: "",
                              },
                              tuesday: {
                                available: false,
                                startTime: "",
                                endTime: "",
                              },
                              wednesday: {
                                available: false,
                                startTime: "",
                                endTime: "",
                              },
                              thursday: {
                                available: false,
                                startTime: "",
                                endTime: "",
                              },
                              friday: {
                                available: false,
                                startTime: "",
                                endTime: "",
                              },
                              saturday: {
                                available: false,
                                startTime: "",
                                endTime: "",
                              },
                              sunday: {
                                available: false,
                                startTime: "",
                                endTime: "",
                              },
                            },
                            hourlyRate: 15,
                            specialties: [],
                            ageGroups: [],
                            bio: "",
                            teachingStyle: "",
                            motivation: "",
                            videoIntroduction: "",
                            profileImage: "",
                            acceptTerms: false,
                            backgroundCheck: false,
                            marketingEmails: false,
                          });
                        }}
                        className="text-green-700 hover:text-green-900 text-xs"
                      >
                        Start Fresh
                      </Button>
                    </div>
                  </AlertDescription>
                </Alert>
              )}

              {error && (
                <Alert variant="destructive" className="mb-6">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {step === 1 && renderStep1()}
              {step === 2 && renderStep2()}
              {step === 3 && renderStep3()}
              {step === 4 && renderStep4()}

              <div className="flex justify-between mt-8">
                {step > 1 && (
                  <Button
                    variant="outline"
                    onClick={() => setStep(step - 1)}
                    disabled={loading}
                  >
                    Back
                  </Button>
                )}
                <div className="flex-1" />
                <Button
                  onClick={handleNext}
                  disabled={loading}
                  className="min-w-[120px]"
                >
                  {loading
                    ? "Submitting..."
                    : step === 4
                      ? "Submit Application"
                      : "Next"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
